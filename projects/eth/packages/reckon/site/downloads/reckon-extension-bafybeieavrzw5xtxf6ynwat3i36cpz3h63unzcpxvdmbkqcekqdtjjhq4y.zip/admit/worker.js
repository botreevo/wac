//wac-worker 1
var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn2, res) => function __init() {
  return fn2 && (res = (0, fn2[__getOwnPropNames(fn2)[0]])(fn2 = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// ../../../../../wac-app/app.gen.ts
var app_gen_exports = {};
__export(app_gen_exports, {
  Host: () => Host,
  __WacRun: () => __WacRun,
  __bindgenSkipped: () => __bindgenSkipped,
  __wacAdvance: () => __wacAdvance,
  __wacAnswered: () => __wacAnswered,
  __wacDone: () => __wacDone,
  __wacHost: () => __wacHost,
  __wacOutstanding: () => __wacOutstanding,
  __wacStart: () => __wacStart,
  __wacStatus: () => __wacStatus,
  main: () => main
});
function $fnref0(f) {
  let slot = $cbs0.indexOf(f);
  if (slot < 0) {
    slot = $cbs0.length;
    if (slot >= 16) {
      throw new RangeError("at most 16 distinct fn[void(i32,i32,i64,i64,string,u8[])] functions can be passed to this module");
    }
    $cbs0.push(f);
  }
  return $exports.$bind$fnref_0(slot);
}
function $fnref1(f) {
  let slot = $cbs1.indexOf(f);
  if (slot < 0) {
    slot = $cbs1.length;
    if (slot >= 16) {
      throw new RangeError("at most 16 distinct fn[i32(i32[],i32)] functions can be passed to this module");
    }
    $cbs1.push(f);
  }
  return $exports.$bind$fnref_1(slot);
}
function $fnref2(f) {
  let slot = $cbs2.indexOf(f);
  if (slot < 0) {
    slot = $cbs2.length;
    if (slot >= 16) {
      throw new RangeError("at most 16 distinct fn[void(i32)] functions can be passed to this module");
    }
    $cbs2.push(f);
  }
  return $exports.$bind$fnref_2(slot);
}
function $fnref3(f) {
  let slot = $cbs3.indexOf(f);
  if (slot < 0) {
    slot = $cbs3.length;
    if (slot >= 16) {
      throw new RangeError("at most 16 distinct fn[bool()] functions can be passed to this module");
    }
    $cbs3.push(f);
  }
  return $exports.$bind$fnref_3(slot);
}
function $buffer(n) {
  $exports.$bind$mem_ensure(n);
  return new Uint8Array($memory.buffer);
}
function $strTo(s) {
  const b = new TextEncoder().encode(s);
  $buffer(b.length).set(b, 0);
  return $exports.$bind$str_from_mem(b.length);
}
function $strFrom(w) {
  const n = $exports.$bind$str_len(w);
  $buffer(n);
  $exports.$bind$str_to_mem(w);
  return new TextDecoder().decode(new Uint8Array($memory.buffer).slice(0, n));
}
function $trapped(e) {
  const said = $exports.$trap$message();
  if (said === null || said === void 0) throw e;
  throw new Error("wac trap: " + $strFrom(said), {
    cause: e
  });
}
function $arrTo_u8(a) {
  const view = $buffer(a.length * 1);
  new Uint8Array(view.buffer, 0, a.length).set(a);
  return $exports.$bind$arr_u8_from_mem(a.length);
}
function $arrFrom_u8(w) {
  const n = $exports.$bind$arr_u8_len(w);
  $buffer(n * 1);
  $exports.$bind$arr_u8_to_mem(w);
  return new Uint8Array($memory.buffer.slice(0, n * 1));
}
function $arrTo_i32(a) {
  const view = $buffer(a.length * 4);
  new Int32Array(view.buffer, 0, a.length).set(a);
  return $exports.$bind$arr_i32_from_mem(a.length);
}
function $arrFrom_i32(w) {
  const n = $exports.$bind$arr_i32_len(w);
  $buffer(n * 4);
  $exports.$bind$arr_i32_to_mem(w);
  return new Int32Array($memory.buffer.slice(0, n * 4));
}
function __wacHost(a0, a1, a2, a3) {
  try {
    return new Host($exports.__wacHost(((v) => v === null ? null : $fnref0(v))(a0), ((v) => v === null ? null : $fnref1(v))(a1), ((v) => v === null ? null : $fnref2(v))(a2), ((v) => v === null ? null : $fnref3(v))(a3)));
  } catch (e) {
    $trapped(e);
  }
}
function __wacAnswered(a0, a1, a2, a3, a4, a5, a6, a7) {
  try {
    $exports.__wacAnswered(((v) => v === null ? null : v.ref)(a0), a1, a2, ((v) => v === null ? null : $strTo(v))(a3), ((v) => v === null ? null : $arrTo_u8(v))(a4), a5, a6, a7);
  } catch (e) {
    $trapped(e);
  }
}
function __wacOutstanding(a0) {
  try {
    return $exports.__wacOutstanding(((v) => v === null ? null : v.ref)(a0));
  } catch (e) {
    $trapped(e);
  }
}
function __wacStart(a0) {
  try {
    return new __WacRun($exports.__wacStart(((v) => v === null ? null : v.ref)(a0)));
  } catch (e) {
    $trapped(e);
  }
}
function __wacAdvance(a0) {
  try {
    return new __WacRun($exports.__wacAdvance(((v) => v === null ? null : v.ref)(a0)));
  } catch (e) {
    $trapped(e);
  }
}
function __wacDone(a0) {
  try {
    return $exports.__wacDone(((v) => v === null ? null : v.ref)(a0)) !== 0;
  } catch (e) {
    $trapped(e);
  }
}
function __wacStatus(a0) {
  try {
    return $exports.__wacStatus(((v) => v === null ? null : v.ref)(a0));
  } catch (e) {
    $trapped(e);
  }
}
function main(a0) {
  try {
    return $exports.main(((v) => v === null ? null : v.ref)(a0));
  } catch (e) {
    $trapped(e);
  }
}
var bytes, $mod, $cbs0, $cbd0, $cbs1, $cbd1, $cbs2, $cbd2, $cbs3, $cbd3, $cbs4, $cbd4, $cbs5, $cbd5, $inst, $exports, $memory, Host, __WacRun, __bindgenSkipped;
var init_app_gen = __esm({
  "../../../../../wac-app/app.gen.ts"() {
    bytes = globalThis.__wacWasm;
    $mod = new WebAssembly.Module(bytes);
    $cbs0 = [];
    $cbd0 = ($slot, a0, a1, a2, a3, a4, a5) => $cbs0[$slot](a0, a1, a2, a3, $strFrom(a4), $arrFrom_u8(a5));
    $cbs1 = [];
    $cbd1 = ($slot, a0, a1) => $cbs1[$slot]($arrFrom_i32(a0), a1);
    $cbs2 = [];
    $cbd2 = ($slot, a0) => $cbs2[$slot](a0);
    $cbs3 = [];
    $cbd3 = ($slot) => $cbs3[$slot]();
    $cbs4 = [];
    $cbd4 = ($slot, a0) => $cbs4[$slot](a0);
    $cbs5 = [];
    $cbd5 = ($slot, a0) => $cbs5[$slot](a0);
    $inst = new WebAssembly.Instance($mod, {
      wac: {
        cb0: $cbd0,
        cb1: $cbd1,
        cb2: $cbd2,
        cb3: $cbd3,
        cb4: $cbd4,
        cb5: $cbd5
      }
    });
    $exports = $inst.exports;
    $memory = $inst.exports.$bind$mem;
    Host = class _Host {
      ref;
      constructor(ref) {
        this.ref = ref;
      }
      get request() {
        return $exports.$bind$s_Host_get_request(this.ref);
      }
      set request(v) {
        $exports.$bind$s_Host_set_request(this.ref, ((v2) => v2 === null ? null : $fnref0(v2))(v));
      }
      get waitAny() {
        return $exports.$bind$s_Host_get_waitAny(this.ref);
      }
      set waitAny(v) {
        $exports.$bind$s_Host_set_waitAny(this.ref, ((v2) => v2 === null ? null : $fnref1(v2))(v));
      }
      get exitWith() {
        return $exports.$bind$s_Host_get_exitWith(this.ref);
      }
      set exitWith(v) {
        $exports.$bind$s_Host_set_exitWith(this.ref, ((v2) => v2 === null ? null : $fnref2(v2))(v));
      }
      get interrupted() {
        return $exports.$bind$s_Host_get_interrupted(this.ref);
      }
      set interrupted(v) {
        $exports.$bind$s_Host_set_interrupted(this.ref, ((v2) => v2 === null ? null : $fnref3(v2))(v));
      }
      get pending() {
        return $exports.$bind$s_Host_get_pending(this.ref);
      }
      set pending(v) {
        $exports.$bind$s_Host_set_pending(this.ref, v);
      }
      get last() {
        return $exports.$bind$s_Host_get_last(this.ref);
      }
      set last(v) {
        $exports.$bind$s_Host_set_last(this.ref, v);
      }
      get yielded() {
        return $exports.$bind$s_Host_get_yielded(this.ref) !== 0;
      }
      set yielded(v) {
        $exports.$bind$s_Host_set_yielded(this.ref, v);
      }
      get queued() {
        return $exports.$bind$s_Host_get_queued(this.ref);
      }
      set queued(v) {
        $exports.$bind$s_Host_set_queued(this.ref, v);
      }
      get parent() {
        return $exports.$bind$s_Host_get_parent(this.ref);
      }
      set parent(v) {
        $exports.$bind$s_Host_set_parent(this.ref, v);
      }
      get parentRanges() {
        return $exports.$bind$s_Host_get_parentRanges(this.ref);
      }
      set parentRanges(v) {
        $exports.$bind$s_Host_set_parentRanges(this.ref, v);
      }
      get routed() {
        return $exports.$bind$s_Host_get_routed(this.ref);
      }
      set routed(v) {
        $exports.$bind$s_Host_set_routed(this.ref, v);
      }
      toObject() {
        return {
          request: this.request,
          waitAny: this.waitAny,
          exitWith: this.exitWith,
          interrupted: this.interrupted,
          pending: this.pending,
          last: this.last,
          yielded: this.yielded,
          queued: this.queued,
          parent: this.parent,
          parentRanges: this.parentRanges,
          routed: this.routed
        };
      }
      static of(a0, a1, a2, a3) {
        return new _Host($exports.$bind$sm_Host_of(((v) => v === null ? null : $fnref0(v))(a0), ((v) => v === null ? null : $fnref1(v))(a1), ((v) => v === null ? null : $fnref2(v))(a2), ((v) => v === null ? null : $fnref3(v))(a3)));
      }
      liveQueued() {
        return $exports.$bind$m_Host_liveQueued(this.ref);
      }
      tell(a0, a1, a2, a3, a4) {
        $exports.$bind$m_Host_tell(this.ref, a0, a1, a2, ((v) => v === null ? null : $strTo(v))(a3), ((v) => v === null ? null : $arrTo_u8(v))(a4));
      }
      waitRouted(a0, a1) {
        return $exports.$bind$m_Host_waitRouted(this.ref, ((v) => v === null ? null : $arrTo_i32(v))(a0), a1);
      }
      parentsRequest(a0) {
        return $exports.$bind$m_Host_parentsRequest(this.ref, a0) !== 0;
      }
    };
    __WacRun = class ___WacRun {
      ref;
      constructor(ref) {
        this.ref = ref;
      }
      static of(advance, done, status) {
        return new ___WacRun($exports.$bind$s___WacRun_new(((v) => v === null ? null : $fnref3(v))(advance), done, status));
      }
      get advance() {
        return $exports.$bind$s___WacRun_get_advance(this.ref);
      }
      set advance(v) {
        $exports.$bind$s___WacRun_set_advance(this.ref, ((v2) => v2 === null ? null : $fnref3(v2))(v));
      }
      get done() {
        return $exports.$bind$s___WacRun_get_done(this.ref) !== 0;
      }
      set done(v) {
        $exports.$bind$s___WacRun_set_done(this.ref, v);
      }
      get status() {
        return $exports.$bind$s___WacRun_get_status(this.ref);
      }
      set status(v) {
        $exports.$bind$s___WacRun_set_status(this.ref, v);
      }
      toObject() {
        return {
          advance: this.advance,
          done: this.done,
          status: this.status
        };
      }
    };
    __bindgenSkipped = [];
  }
});

// ../wac-e2/packages/platform/host/layout.ts
var SLOTS = 128;
var BUFS = 8;
var INLINE_BYTES = 4096;
var BUF_BYTES = 1 << 17;
var CHUNK = 1 << 16;
var SUBMIT_SEQ = 0;
var DONE_SEQ = 1;
var HOST_GONE = 2;
var CTRL_HEAD = 3;
var SLOT_INTS = 8;
var S_STATUS = 0;
var S_OP = 1;
var S_REQ_LEN = 2;
var S_RES_LEN = 3;
var S_RES_STATUS = 4;
var S_ID = 5;
var S_REQ_BUF = 6;
var S_RES_BUF = 7;
var ST_FREE = 0;
var ST_PENDING = 1;
var ST_READY = 3;
var ST_CLAIMED = 5;
var STATUS_ERR = 1;
var STATUS_MORE = 2;
var OP_CONTINUE = -1;
var OP_PUSH = -2;
var OP_ANSWER = -3;
var REQ_FREE_AT = CTRL_HEAD;
var RES_FREE_AT = REQ_FREE_AT + BUFS;
var SLOTS_AT = RES_FREE_AT + BUFS;
var CTRL_INTS = SLOTS_AT + SLOTS * SLOT_INTS;
var CTRL_BYTES = CTRL_INTS * 4;
var REQ_OFFSET = CTRL_BYTES;
var RES_OFFSET = REQ_OFFSET + BUFS * BUF_BYTES;
var INLINE_OFFSET = RES_OFFSET + BUFS * BUF_BYTES;
var TOTAL_BYTES = INLINE_OFFSET + SLOTS * INLINE_BYTES;
function acquireBuf(b, dir) {
  const base = dir === "req" ? REQ_FREE_AT : RES_FREE_AT;
  for (let i = 0; i < BUFS; i++) {
    if (Atomics.compareExchange(b.ctrl, base + i, 0, 1) === 0) return i;
  }
  return -1;
}
function releaseBuf(b, dir, i) {
  if (i < 0) return;
  Atomics.store(b.ctrl, (dir === "req" ? REQ_FREE_AT : RES_FREE_AT) + i, 0);
}
function attach(b, at, field, i) {
  Atomics.store(b.ctrl, at + field, i + 1);
}
function attached(b, at, field) {
  return Atomics.load(b.ctrl, at + field) - 1;
}
function detach(b, at, field) {
  return Atomics.exchange(b.ctrl, at + field, 0) - 1;
}
function slotAt(i) {
  return SLOTS_AT + i * SLOT_INTS;
}
function bridgeOf(sab) {
  const ctrl = new Int32Array(sab, 0, CTRL_INTS);
  const reqs = [];
  const ress = [];
  for (let i = 0; i < BUFS; i++) {
    reqs.push(new Uint8Array(sab, REQ_OFFSET + i * BUF_BYTES, BUF_BYTES));
    ress.push(new Uint8Array(sab, RES_OFFSET + i * BUF_BYTES, BUF_BYTES));
  }
  const inlines = [];
  for (let i = 0; i < SLOTS; i++) {
    inlines.push(new Uint8Array(sab, INLINE_OFFSET + i * INLINE_BYTES, INLINE_BYTES));
  }
  const b = {
    sab,
    ctrl,
    reqBuf: (i) => reqs[i],
    resBuf: (i) => ress[i],
    inline: (i) => inlines[i],
    rebind: (next) => {
      b.sab = next;
      b.ctrl = new Int32Array(next, 0, CTRL_INTS);
      for (let i = 0; i < BUFS; i++) {
        reqs[i] = new Uint8Array(next, REQ_OFFSET + i * BUF_BYTES, BUF_BYTES);
        ress[i] = new Uint8Array(next, RES_OFFSET + i * BUF_BYTES, BUF_BYTES);
      }
      for (let i = 0; i < SLOTS; i++) {
        inlines[i] = new Uint8Array(next, INLINE_OFFSET + i * INLINE_BYTES, INLINE_BYTES);
      }
    }
  };
  return b;
}

// ../wac-e2/packages/platform/host/faults.ts
var FAULT_NONE = 0;
var FAULT_OTHER = 5;
var FAULT_NOT_GRANTED = 7;
var FAULT_UNSUPPORTED = 9;
var CHANGED_OK = new Uint8Array([
  FAULT_NONE
]);
var STAT_FAULT = 20;
var STAT_EXEC = 21;
var STAT_MODE = 22;

// ../wac-e2/packages/platform/host/ops.ts
var OP = {
  NOW_MILLIS: 1,
  MONOTONIC_NANOS: 2,
  RANDOM_BYTES: 3,
  // 4 and 5 were `LOG` and `WARN`, lines a host printed for the program. Retired rather than reused: a line is
  // bytes on standard output or error, `WRITE_STDOUT` and `WRITE_STDERR` (design/system/0013 step 6).
  ARG_COUNT: 6,
  ARG: 7,
  ENV: 8,
  READ_FILE: 9,
  WRITE_FILE: 10,
  READ_STDIN: 11,
  WRITE_STDOUT: 12,
  STAT: 13,
  READ_DIR: 14,
  MKDIR: 15,
  REMOVE: 16,
  RENAME: 17,
  // 18 and 20 were `OPEN_INPUT` and `OPEN_OUTPUT`, which redirected standard input and output to a
  // file. Retired with `Cli` rather than reused (design/system/0013 step 6): a program streams a file
  // through `OPEN_FILE`.
  READ_CHUNK: 19,
  CONNECT: 21,
  LISTEN: 22,
  ACCEPT: 23,
  RECV: 24,
  SEND: 25,
  CLOSE_SOCKET: 26,
  SPAWN: 27,
  EXIT_CODE: 28,
  CLOSE_FEED: 29,
  SLEEP_MILLIS: 30,
  // 31–40 were std's `Page` — render, text, values, events, title, pixels, files, downloads — and
  // 51 and 56 its style and partial blit. Retired rather than reused: a page is `web`'s
  // `main(Page)` now, which talks to the document by messages and needs no bridge
  // (design/system/0011 step 7).
  CWD: 41,
  // 42 and 43 were `PUSH_CHILD` and `POP_CHILD`, an applet run in process as a frame. Retired with
  // `Cli` rather than reused (design/system/0013 step 6): nothing called them but `Cli`'s own fields.
  // 44 was `EXEC`, the same capability without an environment or a choice about the child's streams.
  // Retired rather than reused — see `EXEC_WITH` at the end.
  // 45 was `OUTPUT_ERROR`, why a write to an `OPEN_OUTPUT` file failed; it went with that.
  LINK_STAT: 47,
  WRITE_STDERR: 48,
  SPAWN_SELF: 49,
  /**
   * "Has the user asked to interrupt?" — `Host.interrupted` in `std/platform.wac`.
   *
   * Answered from what the host already knows, so it starts nothing; it still parks the worker like
   * every opcode, and that is the point rather than the cost — see the note in `provider.ts`.
   */
  ASK_INTERRUPT: 50,
  /**
   * "Make this file executable, or stop it being" — `Files.setExecutable` in `std/platform.wac`.
   *
   * One bit rather than a mode, because git's regular-file modes differ only in that bit and because a
   * browser's OPFS has no mode bits at all, so a general `chmod` would be unanswerable on one of the four
   * hosts rather than merely unsupported on it.
   */
  SET_EXECUTABLE: 52,
  // **Datagrams**, which are not `connect`/`recv`/`send` with a flag. A QUIC server answers many
  // peers from one socket and a connection is identified by its connection ID rather than by an
  // address, so a peer may move mid-connection; a connected socket represents neither. See
  // design/system 0007. `CLOSE_SOCKET` closes one of these too — a handle is a handle.
  BIND_DATAGRAM: 53,
  RECEIVE_FROM: 54,
  SEND_TO: 55,
  /**
   * End a socket's outbound direction and keep reading — `issues/system/0215`.
   *
   * Its own opcode rather than a flag on `CLOSE_SOCKET`, because a host that did not know about the
   * flag would close both directions and the program would hang on a reply that can never come. An
   * unserved opcode fails and names itself.
   */
  CLOSE_SEND: 57,
  /**
   * `Procs.exec` — a host program, run to completion, in a directory. `issues/system/0165`, `0290b`.
   *
   * **44 and 58 were earlier spellings of it, and are not reused**: a binary or a worker bundle built
   * before still sends them and should fail rather than be misread — a host that had not been rebuilt
   * would read the environment or the directory as the head of standard input, silently, where an
   * opcode it does not serve fails and names itself. They are not listed here because
   * `conformance_test.wac` reads this table as *the surface*.
   */
  EXEC: 59,
  /**
   * "Set this file's permission bits" — `Files.chmod` in `std/platform.wac`.
   *
   * `SET_EXECUTABLE` above is the narrow form and stays: it promises one bit and changes one bit,
   * which is what a git checkout wants. This promises the mode. `issues/system/0296c`.
   */
  CHMOD: 60,
  OPEN_FILE: 61,
  CLOSE_FILE: 62,
  CLOSE_OUTPUT: 63,
  // **Answered in the worker's own realm and never sent to the launcher**: a loaded module lives in
  // the caller's realm, its requests served over the caller's own bridge, so nothing about it crosses.
  // Numbered because std asks for them like any other request. `issues/system/0240c`.
  LOAD: 64,
  CALL: 65,
  UNLOAD: 66,
  VALIDATE: 67,
  // A capability by name: `wac.http` in a page that was granted the network (`hosthttp.ts`), none elsewhere; a parent
  // serving a child answers its lookups itself.
  CAPABILITY: 68,
  /**
   * A file opened with `OPEN_FILE` how 3 (read anywhere) or 4 (read and write anywhere, created if absent and never
   * emptied) — `Files.openRandom`. Each names its handle first. `READ_AT`: offset, length → the bytes there.
   */
  READ_AT: 69,
  /** Offset, bytes: written there, the file growing as it needs to. */
  WRITE_AT: 70,
  /** → the file's size. */
  FILE_SIZE: 71,
  /** The size to cut or grow it to. */
  TRUNCATE_FILE: 72,
  /** What was written is on the disk before this answers: `fsync`. */
  SYNC_FILE: 73
};
var GRANT_READ = 1;
var GRANT_WRITE = 2;
var GRANT_NET = 4;
var GRANT_ENV = 8;
var GRANT_RUN = 16;

// ../wac-e2/packages/platform/host/call.ts
var enc = new TextEncoder();
var dec = new TextDecoder();
var HostCallError = class extends Error {
  fault;
  constructor(message, fault = 5) {
    super(message);
    this.fault = fault;
  }
};
function faultedMessage(bytes2) {
  if (bytes2.length === 0) return {
    fault: 5,
    message: ""
  };
  return {
    fault: bytes2[0],
    message: new TextDecoder().decode(bytes2.subarray(1))
  };
}
var OP_NAMES = Object.fromEntries(Object.entries(OP).map(([name, op]) => [
  op,
  name
]));
var callsOf = /* @__PURE__ */ new WeakMap();
function calls(b) {
  let c = callsOf.get(b);
  if (c === void 0) {
    c = {
      next: 1,
      outstanding: /* @__PURE__ */ new Set(),
      answered: /* @__PURE__ */ new Map(),
      pieces: /* @__PURE__ */ new Map(),
      dropped: /* @__PURE__ */ new Set()
    };
    callsOf.set(b, c);
  }
  return c;
}
function takeReqBuf(b) {
  for (; ; ) {
    const seen = Atomics.load(b.ctrl, DONE_SEQ);
    const i = acquireBuf(b, "req");
    if (i >= 0) return i;
    parkForHost(b, seen);
  }
}
function ping(b) {
  Atomics.add(b.ctrl, SUBMIT_SEQ, 1);
  Atomics.notify(b.ctrl, SUBMIT_SEQ);
}
function parkForHost(b, seen, millis = Infinity) {
  gone(b);
  Atomics.wait(b.ctrl, DONE_SEQ, seen, millis);
  gone(b);
}
function gone(b) {
  if (Atomics.load(b.ctrl, HOST_GONE) === 0) return;
  throw new HostCallError("the host stopped answering: this program's capabilities are gone, so the call cannot complete", FAULT_OTHER);
}
function claim(b) {
  for (; ; ) {
    const seen = Atomics.load(b.ctrl, DONE_SEQ);
    for (let i = 0; i < SLOTS; i++) {
      if (Atomics.compareExchange(b.ctrl, slotAt(i) + S_STATUS, ST_FREE, ST_CLAIMED) === ST_FREE) {
        return i;
      }
    }
    if (drain(b) > 0) continue;
    parkForHost(b, seen);
  }
}
function drain(b) {
  const c = calls(b);
  let freed = 0;
  for (let i = 0; i < SLOTS; i++) {
    const at = slotAt(i);
    if (Atomics.load(b.ctrl, at + S_STATUS) !== ST_READY) continue;
    const op = Atomics.load(b.ctrl, at + S_OP);
    if (op !== OP_ANSWER && op !== OP_CONTINUE) continue;
    const id = Atomics.load(b.ctrl, at + S_ID);
    const status = Atomics.load(b.ctrl, at + S_RES_STATUS);
    const piece = readRes(b, at);
    const kept = !c.dropped.has(id);
    if (status === STATUS_MORE) {
      if (kept) {
        const so = c.pieces.get(id);
        if (so === void 0) c.pieces.set(id, [
          piece
        ]);
        else so.push(piece);
      }
      Atomics.store(b.ctrl, at + S_OP, OP_CONTINUE);
      Atomics.store(b.ctrl, at + S_REQ_LEN, 0);
      Atomics.store(b.ctrl, at + S_STATUS, ST_PENDING);
      ping(b);
      continue;
    }
    const before = c.pieces.get(id);
    c.pieces.delete(id);
    if (kept) c.answered.set(id, {
      status,
      bytes: before === void 0 ? piece : joined(before, piece)
    });
    else c.dropped.delete(id);
    release(b, i);
    freed++;
  }
  return freed;
}
function joined(parts, last) {
  const out = new Uint8Array(parts.reduce((n, p) => n + p.length, 0) + last.length);
  let into = 0;
  for (const p of parts) {
    out.set(p, into);
    into += p.length;
  }
  out.set(last, into);
  return out;
}
function awaitReady(b, slot) {
  const at = slotAt(slot);
  for (; ; ) {
    const seen = Atomics.load(b.ctrl, DONE_SEQ);
    if (Atomics.load(b.ctrl, at + S_STATUS) === ST_READY) return;
    parkForHost(b, seen);
  }
}
function slotOf(at) {
  return (at - slotAt(0)) / SLOT_INTS;
}
function readRes(b, at) {
  const len = Atomics.load(b.ctrl, at + S_RES_LEN);
  const bi = attached(b, at, S_RES_BUF);
  const out = (bi < 0 ? b.inline(slotOf(at)) : b.resBuf(bi)).slice(0, len);
  detach(b, at, S_RES_BUF);
  releaseBuf(b, "res", bi);
  ping(b);
  return out;
}
function release(b, slot) {
  const at = slotAt(slot);
  releaseBuf(b, "res", detach(b, at, S_RES_BUF));
  Atomics.store(b.ctrl, at + S_STATUS, ST_FREE);
  ping(b);
}
function submit(b, op, payload) {
  const c = calls(b);
  const id = c.next;
  c.next = c.next >= 2147483647 ? 1 : c.next + 1;
  const slot = claim(b);
  const at = slotAt(slot);
  Atomics.store(b.ctrl, at + S_ID, id);
  let sent = 0;
  while (payload.length - sent > BUF_BYTES) {
    const bi2 = takeReqBuf(b);
    b.reqBuf(bi2).set(payload.subarray(sent, sent + BUF_BYTES), 0);
    attach(b, at, S_REQ_BUF, bi2);
    Atomics.store(b.ctrl, at + S_OP, OP_PUSH);
    Atomics.store(b.ctrl, at + S_REQ_LEN, BUF_BYTES);
    Atomics.store(b.ctrl, at + S_STATUS, ST_PENDING);
    ping(b);
    awaitReady(b, slot);
    const acked = readRes(b, at);
    if (Atomics.load(b.ctrl, at + S_RES_STATUS) === STATUS_ERR) {
      const said = faultedMessage(acked);
      release(b, slot);
      throw new HostCallError(said.message, said.fault);
    }
    sent += BUF_BYTES;
  }
  const tail = payload.subarray(sent);
  const bi = takeReqBuf(b);
  b.reqBuf(bi).set(tail, 0);
  attach(b, at, S_REQ_BUF, bi);
  Atomics.store(b.ctrl, at + S_OP, op);
  Atomics.store(b.ctrl, at + S_REQ_LEN, tail.length);
  c.outstanding.add(id);
  Atomics.store(b.ctrl, at + S_STATUS, ST_PENDING);
  ping(b);
  return {
    id
  };
}
function isDone(b, t) {
  drain(b);
  const c = calls(b);
  return c.answered.has(t.id) || !c.outstanding.has(t.id);
}
function waitAny(b, tickets, millis = -1) {
  if (tickets.length === 0) return null;
  const deadline = millis < 0 ? Infinity : performance.now() + millis;
  const c = calls(b);
  for (; ; ) {
    const seen = Atomics.load(b.ctrl, DONE_SEQ);
    drain(b);
    for (const t of tickets) if (c.answered.has(t.id) || !c.outstanding.has(t.id)) return t;
    const left = deadline - performance.now();
    if (left <= 0) return null;
    parkForHost(b, seen, left);
  }
}
function collect(b, t) {
  const c = calls(b);
  if (!c.outstanding.has(t.id) && !c.answered.has(t.id)) {
    throw new HostCallError("this call was already collected or cancelled");
  }
  for (; ; ) {
    const seen = Atomics.load(b.ctrl, DONE_SEQ);
    drain(b);
    const got = c.answered.get(t.id);
    if (got !== void 0) {
      c.answered.delete(t.id);
      c.outstanding.delete(t.id);
      if (got.status === STATUS_ERR) {
        const said = faultedMessage(got.bytes);
        throw new HostCallError(said.message, said.fault);
      }
      return got.bytes;
    }
    parkForHost(b, seen);
  }
}
function cancel(b, t) {
  const c = calls(b);
  if (c.answered.delete(t.id)) {
    c.outstanding.delete(t.id);
    return;
  }
  if (!c.outstanding.delete(t.id)) return;
  c.dropped.add(t.id);
}
function hostCall(b, op, payload) {
  return collect(b, submit(b, op, payload));
}
var str = (s) => enc.encode(s);
var EMPTY_ARG = new Uint8Array(0);
var unstr = (b) => dec.decode(b);
function i32le(n) {
  const b = new Uint8Array(4);
  new DataView(b.buffer).setInt32(0, n, true);
  return b;
}
function readI32le(b, at = 0) {
  return new DataView(b.buffer, b.byteOffset, b.byteLength).getInt32(at, true);
}
function i64le(n) {
  const b = new Uint8Array(8);
  new DataView(b.buffer).setBigInt64(0, n, true);
  return b;
}
function readI64le(b, at = 0) {
  return new DataView(b.buffer, b.byteOffset, b.byteLength).getBigInt64(at, true);
}

// ../wac-e2/packages/platform/host/respond.ts
var EMPTY = new Uint8Array(0);

// ../wac-e2/packages/platform/host/entropy.ts
var MOST = 1 << 20;

// ../wac-e2/packages/platform/host/hosthttp.ts
var HOST_HTTP = {
  name: "wac.http",
  version: "1.0.0",
  base: 4096,
  count: 3
};
var HTTP_OPEN = HOST_HTTP.base;
var HTTP_READ = HOST_HTTP.base + 1;
var HTTP_CLOSE = HOST_HTTP.base + 2;
var FAULT_UNSUPPORTED2 = 9;
function versionMatches(cap, versions) {
  const v = versions.trim().replace(/^[\^~=v]+/, "");
  if (v === "" || v === "*") return true;
  const want2 = v.split(".")[0];
  return want2 === cap.version.split(".")[0];
}
var enc2 = new TextEncoder();
var dec2 = new TextDecoder();
function capRequest(a, b, text, bytes2) {
  const t = enc2.encode(text);
  const out = new Uint8Array(20 + t.length + bytes2.length);
  out.set(i64le(a), 0);
  out.set(i64le(b), 8);
  out.set(i32le(t.length), 16);
  out.set(t, 20);
  out.set(bytes2, 20 + t.length);
  return out;
}
function readCapAnswer(p) {
  const tl = readI32le(p, 20);
  return {
    n: readI64le(p, 0),
    m: readI64le(p, 8),
    flags: readI32le(p, 16),
    text: dec2.decode(p.subarray(24, 24 + tl)),
    bytes: p.slice(24 + tl)
  };
}
function notProvided(name) {
  return {
    fault: FAULT_UNSUPPORTED2,
    text: `no capability ${name} on this host`
  };
}

// ../wac-e2/packages/platform/host/queue.ts
var EMPTY2 = new Uint8Array(0);

// ../wac-e2/packages/platform/host/children.ts
var QUEUE_CAP = 8 << 20;

// ../wac-e2/packages/platform/host/browser.ts
var EMPTY3 = new Uint8Array(0);
var END = new Uint8Array([
  1
]);

// ../wac-e2/packages/platform/host/marshal.ts
var SCALARS = /* @__PURE__ */ new Set([
  "i8",
  "u8",
  "i16",
  "u16",
  "i32",
  "u32",
  "i64",
  "u64",
  "f32",
  "f64",
  "bool"
]);
function bindName(name) {
  return name.replace(/[^A-Za-z0-9_]+/g, "$").replace(/^\$+|\$+$/g, "");
}
function arrSuffix(elem) {
  switch (elem.kind) {
    case "scalar":
      return elem.name;
    case "string":
      return "string";
    // Nested: the outer array of `i32[][]` is `i32Arr`, so its helper is `$bind$arr_i32Arr_get`.
    case "array":
      return `${elem.suffix}Arr`;
    case "ref":
      return bindName(elem.name);
    case "void":
      return "void";
  }
}
function shapeOf(type) {
  const t = type.trim();
  if (t.endsWith("?")) {
    const inner = shapeOf(t.slice(0, -1));
    return inner.kind === "array" ? {
      ...inner
    } : inner;
  }
  if (t === "void" || t === "") return {
    kind: "void"
  };
  if (t === "string") return {
    kind: "string"
  };
  if (SCALARS.has(t)) return {
    kind: "scalar",
    name: t
  };
  if (t.endsWith("[]")) {
    const elem = shapeOf(t.slice(0, -2));
    return {
      kind: "array",
      elem,
      suffix: arrSuffix(elem)
    };
  }
  return {
    kind: "ref",
    name: t
  };
}
var call = (b, name, ...args) => {
  const f = b.exports[name];
  if (typeof f !== "function") {
    throw new Error(`marshal: the module exports no ${name}`);
  }
  return f(...args);
};
function stringFrom(b, w) {
  const n = call(b, "$bind$str_len", w);
  call(b, "$bind$mem_ensure", n);
  call(b, "$bind$str_to_mem", w);
  return new TextDecoder().decode(new Uint8Array(b.memory()).slice(0, n));
}
function bytesFrom(b, w) {
  const n = call(b, "$bind$arr_u8_len", w);
  call(b, "$bind$mem_ensure", n);
  call(b, "$bind$arr_u8_to_mem", w);
  return new Uint8Array(b.memory()).slice(0, n);
}
function fromWasm(b, shape, w) {
  switch (shape.kind) {
    case "void":
      return void 0;
    case "scalar":
      return shape.name === "bool" ? w !== 0 : w;
    case "string":
      return stringFrom(b, w);
    case "ref":
      return w;
    case "array": {
      if (w === null || w === void 0) return null;
      if (shape.elem.kind === "scalar" && shape.elem.name === "u8") return bytesFrom(b, w);
      const n = call(b, `$bind$arr_${shape.suffix}_len`, w);
      const out = [];
      for (let i = 0; i < n; i++) {
        out.push(fromWasm(b, shape.elem, call(b, `$bind$arr_${shape.suffix}_get`, w, i)));
      }
      return out;
    }
  }
}
function give(b, make, data) {
  call(b, "$bind$mem_ensure", data.length);
  new Uint8Array(b.memory()).set(data, 0);
  return call(b, make, data.length);
}
function toWasm(b, shape, v) {
  switch (shape.kind) {
    case "void":
      return void 0;
    case "scalar":
      return shape.name === "bool" ? v ? 1 : 0 : v;
    case "string":
      return give(b, "$bind$str_from_mem", new TextEncoder().encode(String(v)));
    case "ref":
      if (v === null || v === void 0) return null;
      return typeof v === "object" && "ref" in v ? v.ref : v;
    case "array": {
      if (v === null || v === void 0) return null;
      const items = v;
      if (shape.elem.kind === "scalar" && shape.elem.name === "u8") {
        return give(b, "$bind$arr_u8_from_mem", Uint8Array.from(items));
      }
      const suffix = shape.suffix;
      const filled = typeof b.exports[`$bind$arr_${suffix}_new0`] === "function";
      if (filled && items.length === 0) return call(b, `$bind$arr_${suffix}_new0`);
      const arr = filled ? call(b, `$bind$arr_${suffix}_new`, items.length, toWasm(b, shape.elem, items[0])) : call(b, `$bind$arr_${suffix}_new`, items.length);
      for (let i = filled ? 1 : 0; i < items.length; i++) {
        call(b, `$bind$arr_${suffix}_set`, arr, i, toWasm(b, shape.elem, items[i]));
      }
      return arr;
    }
  }
}

// ../wac-e2/packages/platform/host/driver.ts
function fn(exports, name) {
  const f = exports[name];
  if (typeof f !== "function") {
    throw new Error(`the module has no ${name}, which its manifest names`);
  }
  return f;
}
function drive(wasm, manifest) {
  const slots = manifest.callbacks.map(() => []);
  const wac = {};
  manifest.callbacks.forEach((cb, j) => {
    wac[cb.field] = (slot, ...rest) => {
      const f = slots[j][slot];
      if (f === void 0) {
        throw new Error(`no function in slot ${slot} of signature ${j} (${cb.type})`);
      }
      const args = cb.params.map((t, i) => driven.fromWasm(t, rest[i]));
      const out = f(...args);
      return cb.ret === "void" ? void 0 : driven.toWasm(cb.ret, out);
    };
  });
  const instance = new WebAssembly.Instance(new WebAssembly.Module(wasm), {
    wac
  });
  const exports = instance.exports;
  const memory = () => exports["$bind$mem"].buffer;
  const bound = {
    exports,
    memory
  };
  const driven = {
    exports,
    fromWasm(type, v) {
      if (v === null || v === void 0) return null;
      return fromWasm(bound, shapeOf(type), v);
    },
    toWasm(type, v) {
      const base = type.endsWith("?") ? type.slice(0, -1) : type;
      if (v === null || v === void 0) return base === "void" ? void 0 : null;
      if (base.startsWith("fn[") && typeof v === "function") {
        const j = manifest.callbacks.findIndex((c) => c.type === base);
        if (j < 0) throw new Error(`${base} has no dispatcher in this manifest`);
        const seen = slots[j].indexOf(v);
        if (seen >= 0) return fn(exports, manifest.callbacks[j].helper)(seen);
        const slot = slots[j].length;
        if (slot >= manifest.callbacks[j].slots) {
          throw new Error(`at most ${manifest.callbacks[j].slots} distinct ${base} functions can be passed to this module`);
        }
        slots[j].push(v);
        return fn(exports, manifest.callbacks[j].helper)(slot);
      }
      return toWasm(bound, shapeOf(base), v);
    }
  };
  return driven;
}
function asAppModule(driven, manifest) {
  const app = {};
  for (const [name, value] of Object.entries(driven.exports)) {
    if (!name.startsWith("$bind$")) app[name] = value;
  }
  for (const sig of manifest.exports) {
    const raw = driven.exports[sig.name];
    if (typeof raw !== "function") continue;
    app[sig.name] = (...a) => {
      const out = raw(...sig.params.map((t, i) => driven.toWasm(t, a[i])));
      return sig.ret === "" || sig.ret === "void" ? void 0 : driven.fromWasm(sig.ret, out);
    };
  }
  app.__wacTrapSaid = () => {
    try {
      const read = driven.exports.$trap$message;
      const s = typeof read === "function" ? read() : null;
      return s === null || s === void 0 ? "" : String(driven.fromWasm("string", s) ?? "");
    } catch {
      return "";
    }
  };
  return app;
}
function manifestIn(wasm) {
  const sections = WebAssembly.Module.customSections(new WebAssembly.Module(wasm), "wac.manifest");
  if (sections.length === 0) return null;
  return JSON.parse(new TextDecoder().decode(sections[0]));
}

// ../wac-e2/packages/platform/host/provider.ts
var EMPTY4 = new Uint8Array(0);
var WacExit = class extends Error {
  // A declared field rather than a parameter property: our TypeScript is erasable by design
  // (`design/system/0009` D4), and `readonly code` in the parameter list is the one construct that is
  // not — TypeScript writes a field for it and an erasing stripper cannot. `issues/system/0360a`.
  code;
  constructor(code) {
    super(`the program exited with ${code}`);
    this.code = code;
  }
};
var flat = (o) => ({
  fault: o.fault ?? FAULT_NONE,
  text: o.text ?? "",
  bytes: o.bytes ?? EMPTY4,
  n: o.n ?? 0n,
  m: o.m ?? 0n,
  flags: o.flags ?? 0
});
var failure = (e) => flat({
  fault: e instanceof HostCallError ? e.fault : FAULT_OTHER,
  text: e instanceof Error ? e.message : String(e)
});
var REFUSED = "Not granted to this application";
var NEEDS = {
  [OP.READ_FILE]: GRANT_READ,
  [OP.STAT]: GRANT_READ,
  [OP.LINK_STAT]: GRANT_READ,
  [OP.READ_DIR]: GRANT_READ,
  [OP.WRITE_FILE]: GRANT_WRITE,
  [OP.MKDIR]: GRANT_WRITE,
  [OP.REMOVE]: GRANT_WRITE,
  [OP.RENAME]: GRANT_WRITE,
  [OP.SET_EXECUTABLE]: GRANT_WRITE,
  [OP.CHMOD]: GRANT_WRITE,
  [OP.CONNECT]: GRANT_NET,
  [OP.LISTEN]: GRANT_NET,
  [OP.BIND_DATAGRAM]: GRANT_NET,
  [OP.ENV]: GRANT_ENV,
  [OP.EXEC]: GRANT_RUN
};
var cat = (...parts) => {
  const out = new Uint8Array(parts.reduce((n, p) => n + p.length, 0));
  let at = 0;
  for (const p of parts) {
    out.set(p, at);
    at += p.length;
  }
  return out;
};
var prefixed = (head, body) => cat(i32le(head.length), head, body);
var flag = (on) => new Uint8Array([
  on ? 1 : 0
]);
var Parts = class {
  at = 0;
  b;
  constructor(b) {
    this.b = b;
  }
  u32() {
    const n = readI32le(this.b, this.at) >>> 0;
    this.at += 4;
    return n;
  }
  part() {
    const n = this.u32();
    const out = this.b.subarray(this.at, this.at + n);
    this.at += n;
    return out;
  }
  list() {
    const n = this.u32();
    const out = [];
    for (let i = 0; i < n; i++) out.push(this.part());
    return out;
  }
};
var argvBytes = (args) => cat(i32le(args.length), ...args.flatMap((a) => [
  i32le(a.length),
  a
]));
var nulJoined = (xs) => cat(...xs.flatMap((x, i) => i === 0 ? [
  x
] : [
  new Uint8Array([
    0
  ]),
  x
]));
function payloadOf(op, a, b, text, bytes2) {
  switch (op) {
    case OP.NOW_MILLIS:
    case OP.MONOTONIC_NANOS:
    case OP.ARG_COUNT:
    case OP.READ_STDIN:
    case OP.READ_CHUNK:
    case OP.CWD:
    case OP.ASK_INTERRUPT:
      return EMPTY4;
    case OP.RANDOM_BYTES:
    case OP.ARG:
    case OP.SLEEP_MILLIS:
    case OP.ACCEPT:
    case OP.RECV:
    case OP.CLOSE_SOCKET:
    case OP.CLOSE_SEND:
    case OP.CLOSE_FILE:
    case OP.CLOSE_OUTPUT:
    case OP.RECEIVE_FROM:
    case OP.CLOSE_FEED:
    case OP.EXIT_CODE:
      return i32le(a);
    case OP.ENV:
    case OP.READ_FILE:
    case OP.STAT:
    case OP.LINK_STAT:
    case OP.READ_DIR:
      return str(text);
    case OP.WRITE_STDOUT:
    case OP.WRITE_STDERR:
      return bytes2;
    case OP.WRITE_FILE:
      return prefixed(str(text), bytes2);
    case OP.MKDIR:
    case OP.REMOVE:
    case OP.SET_EXECUTABLE:
      return cat(flag(a !== 0), str(text));
    case OP.RENAME:
      return prefixed(str(text), bytes2);
    case OP.CHMOD:
    case OP.OPEN_FILE:
    case OP.CONNECT:
    case OP.LISTEN:
    case OP.BIND_DATAGRAM:
      return cat(i32le(a), str(text));
    case OP.SEND:
      return cat(i32le(a), bytes2);
    // A file `openRandom` opened: the handle, then the offset as an i64, then what std put in `bytes` — the length
    // to read as four bytes, or what to write.
    case OP.READ_AT:
    case OP.WRITE_AT:
      return cat(i32le(a), i64le(BigInt(b)), bytes2);
    case OP.TRUNCATE_FILE:
      return cat(i32le(a), i64le(BigInt(b)));
    case OP.FILE_SIZE:
    case OP.SYNC_FILE:
      return i32le(a);
    case OP.SEND_TO: {
      const who = str(text);
      return cat(i32le(a), i32le(b), i32le(who.length), who, bytes2);
    }
    case OP.SPAWN:
    case OP.SPAWN_SELF: {
      const serves = (b & 256) !== 0;
      const inherit = b & 3;
      const tail = prefixed(str(text), cat(op === OP.SPAWN ? i32le(inherit) : new Uint8Array([
        inherit
      ]), flag(serves)));
      if (op === OP.SPAWN) return cat(i32le(a), bytes2, tail);
      const p = new Parts(bytes2);
      p.part();
      return cat(i32le(a), argvBytes(p.list()), tail);
    }
    case OP.EXEC: {
      const p = new Parts(bytes2);
      const program = p.part();
      const args = p.list();
      const input = p.part();
      const pairs = p.list();
      return cat(flag((a & 1) !== 0), flag((a & 2) !== 0), prefixed(program, prefixed(nulJoined(args), prefixed(nulJoined(pairs), prefixed(str(text), input)))));
    }
    default:
      return null;
  }
}
var socketOf = (out) => flat({
  n: BigInt(readI32le(out)),
  m: BigInt(readI32le(out, 4)),
  text: unstr(out.subarray(8))
});
var changeOf = (out) => out.length === 0 || out[0] === FAULT_NONE ? flat({
  flags: 1
}) : flat({
  fault: out[0],
  text: unstr(out.subarray(1))
});
var readOf = (out) => {
  if (out.length === 0 || out[0] === 1) return flat({
    flags: 1
  });
  if (out[0] === 2) return flat({
    fault: FAULT_OTHER,
    text: unstr(out.subarray(1))
  });
  return flat({
    bytes: out.slice(1)
  });
};
function answerOf(op, out) {
  if (op >= HOST_HTTP.base && op < HOST_HTTP.base + HOST_HTTP.count) {
    const x = readCapAnswer(out);
    return flat({
      n: x.n,
      m: x.m,
      flags: x.flags,
      text: x.text,
      bytes: x.bytes
    });
  }
  switch (op) {
    case OP.NOW_MILLIS:
    case OP.MONOTONIC_NANOS:
    case OP.SLEEP_MILLIS:
      return flat({
        n: readI64le(out)
      });
    case OP.ARG_COUNT:
    case OP.EXIT_CODE:
      return flat({
        n: BigInt(readI32le(out))
      });
    case OP.RANDOM_BYTES:
    case OP.ARG:
    case OP.READ_STDIN:
    case OP.READ_FILE:
      return flat({
        bytes: out,
        flags: 1
      });
    case OP.ENV:
      return out[0] === 1 ? flat({
        bytes: out.slice(1),
        flags: 1
      }) : flat({});
    case OP.CWD:
      return flat({
        text: unstr(out)
      });
    case OP.READ_CHUNK:
    case OP.RECV:
      return readOf(out);
    case OP.WRITE_FILE:
    case OP.MKDIR:
    case OP.REMOVE:
    case OP.RENAME:
    case OP.SET_EXECUTABLE:
    case OP.CHMOD:
      return changeOf(out);
    case OP.WRITE_STDOUT:
    case OP.WRITE_STDERR:
    case OP.SEND:
    case OP.SEND_TO:
    case OP.CLOSE_FILE:
    case OP.CLOSE_OUTPUT:
    case OP.WRITE_AT:
    case OP.TRUNCATE_FILE:
    case OP.SYNC_FILE:
      return flat({
        flags: 1
      });
    case OP.READ_AT:
      return flat({
        bytes: out.slice()
      });
    case OP.FILE_SIZE:
      return flat({
        n: readI64le(out)
      });
    case OP.STAT:
    case OP.LINK_STAT: {
      const fault = out[STAT_FAULT] ?? 0;
      if (fault !== FAULT_NONE) return flat({
        fault
      });
      const dv = new DataView(out.buffer, out.byteOffset, out.byteLength);
      const kind = (out[0] === 1 ? 1 : 0) | (out[1] === 1 ? 2 : 0) | (out[2] === 1 ? 4 : 0) | (out[19] === 1 ? 8 : 0) | (out[STAT_EXEC] === 1 ? 16 : 0);
      const mode = out.length >= STAT_MODE + 4 ? dv.getUint32(STAT_MODE, true) & 65535 : 0;
      return flat({
        n: dv.getBigInt64(3, true),
        m: dv.getBigInt64(11, true),
        flags: kind | mode << 16
      });
    }
    case OP.READ_DIR: {
      const names = out.length === 0 ? [] : unstr(out).split("\0");
      return flat({
        bytes: str(names.map((n) => n + "\0").join("")),
        flags: 1
      });
    }
    case OP.CONNECT:
    case OP.LISTEN:
    case OP.ACCEPT:
    case OP.BIND_DATAGRAM:
    case OP.OPEN_FILE:
      return socketOf(out);
    case OP.RECEIVE_FROM: {
      const peerLen = readI32le(out, 4);
      return flat({
        bytes: out.slice(8 + peerLen),
        text: unstr(out.subarray(8, 8 + peerLen)),
        n: BigInt(readI32le(out))
      });
    }
    case OP.SPAWN:
    case OP.SPAWN_SELF: {
      const handle = readI32le(out);
      if (handle < 0) {
        return flat({
          fault: handle === -2 ? FAULT_UNSUPPORTED : FAULT_OTHER,
          text: unstr(out.subarray(12))
        });
      }
      const err = BigInt.asUintN(32, BigInt(readI32le(out, 4)));
      const fs = BigInt(readI32le(out, 8));
      return flat({
        n: BigInt(handle),
        m: BigInt.asIntN(64, err | fs << 32n)
      });
    }
    case OP.EXEC: {
      const nOut = readI32le(out, 4);
      const nErr = readI32le(out, 8);
      const why = unstr(out.subarray(12 + nOut + nErr));
      if (why !== "") return flat({
        fault: FAULT_OTHER,
        text: why
      });
      return flat({
        n: BigInt(readI32le(out) | 0),
        bytes: out.slice(12, 12 + nOut + nErr),
        m: BigInt(nOut)
      });
    }
    default:
      return flat({});
  }
}
var closerOf = (op) => {
  switch (op) {
    case OP.CONNECT:
    case OP.LISTEN:
    case OP.ACCEPT:
    case OP.BIND_DATAGRAM:
    case OP.SPAWN:
    case OP.SPAWN_SELF:
      return OP.CLOSE_SOCKET;
    case OP.OPEN_FILE:
      return OP.CLOSE_FILE;
    default:
      return null;
  }
};
var AT_ONCE = /* @__PURE__ */ new Set([
  OP.NOW_MILLIS,
  OP.MONOTONIC_NANOS,
  OP.RANDOM_BYTES,
  OP.ARG_COUNT,
  OP.ARG,
  OP.ENV,
  OP.CWD,
  OP.WRITE_STDOUT,
  OP.WRITE_STDERR,
  OP.CLOSE_OUTPUT,
  OP.CLOSE_SOCKET,
  OP.CLOSE_SEND,
  OP.CLOSE_FEED
]);
var loadedModules = /* @__PURE__ */ new Map();
var nextLoaded = 1;
function load(b, module, asked) {
  try {
    const manifest = manifestIn(module);
    if (manifest === null) return flat({
      fault: FAULT_OTHER,
      text: "this module carries no wac.manifest section"
    });
    const driven = drive(module, manifest);
    const app = asAppModule(driven, manifest);
    const handle = nextLoaded++;
    loadedModules.set(handle, {
      driven,
      app,
      // **Narrowed to what was asked for** — `issues/system/0242c`. The launcher cannot tell this
      // module's calls from its loader's, so the narrowing is in the host it is handed.
      host: hostFor(b, app, asked),
      exports: new Map(manifest.exports.map((e) => [
        e.name,
        e
      ]))
    });
    return flat({
      n: BigInt(handle)
    });
  } catch (e) {
    return flat({
      fault: FAULT_OTHER,
      text: e instanceof Error ? e.message : String(e)
    });
  }
}
function call2(handle, name, arg) {
  const m = loadedModules.get(handle);
  if (m === void 0) return flat({
    flags: 2,
    text: "no module on handle " + handle
  });
  const sig = m.exports.get(name);
  const f = m.app[name];
  if (sig === void 0 || typeof f !== "function") return flat({
    flags: 2,
    text: "no export named " + name
  });
  let args;
  if (sig.params.length === 0) args = [];
  else if (sig.params.length === 1 && sig.params[0] === "i32") args = [
    arg
  ];
  else if (sig.params.length === 1 && sig.params[0] === m.exports.get("__wacHost")?.ret) {
    if (m.host === void 0) return flat({
      flags: 3,
      text: "this module was built without a host"
    });
    args = [
      m.host
    ];
  } else return flat({
    flags: 3,
    text: "cannot call " + name + "(" + sig.params.join(", ") + ")"
  });
  if (sig.ret !== "" && sig.ret !== "void" && sig.ret !== "i32" && sig.ret !== "string") {
    return flat({
      flags: 3,
      text: name + " answers " + sig.ret
    });
  }
  try {
    const out = f(...args);
    if (sig.ret === "string") return flat({
      text: String(out ?? "")
    });
    if (sig.ret === "i32") return flat({
      n: BigInt(Number(out) | 0)
    });
    return flat({});
  } catch {
    let said = "";
    try {
      const read = m.driven.exports.$trap$message;
      const s = typeof read === "function" ? read() : null;
      if (s !== null && s !== void 0) said = String(m.driven.fromWasm("string", s) ?? "");
    } catch {
    }
    return flat({
      flags: 1,
      text: said
    });
  }
}
function validate(module) {
  const bytes2 = module;
  if (WebAssembly.validate(bytes2)) return flat({});
  try {
    new WebAssembly.Module(bytes2);
    return flat({
      fault: FAULT_OTHER,
      text: "the engine disagreed with itself about this module"
    });
  } catch (e) {
    return flat({
      fault: FAULT_OTHER,
      text: e instanceof Error ? e.message : String(e)
    });
  }
}
function hostFor(b, app, grants, provides = []) {
  const make = app.__wacHost;
  const answered = app.__wacAnswered;
  if (typeof make !== "function" || typeof answered !== "function") return void 0;
  const flights = /* @__PURE__ */ new Map();
  let dropped = [];
  let h = void 0;
  const deliver = (id, f) => {
    if (id === 0) return;
    answered(h, id, f.fault, f.text, f.bytes, f.n, f.m, f.flags);
  };
  const reply = (op, t) => {
    try {
      return answerOf(op, collect(b, t));
    } catch (e) {
      return failure(e);
    }
  };
  const reap = () => {
    if (dropped.length === 0) return;
    const still = [];
    for (const d of dropped) {
      if (!isDone(b, d.t)) {
        still.push(d);
        continue;
      }
      const f = reply(d.op, d.t);
      const close = closerOf(d.op);
      if (f.fault === FAULT_NONE && close !== null) {
        try {
          hostCall(b, close, i32le(Number(f.n)));
        } catch {
        }
      }
    }
    dropped = still;
  };
  const deliverReady = (ids) => {
    for (const id of ids) {
      const f = flights.get(id);
      if (f === void 0 || !isDone(b, f.t)) continue;
      flights.delete(id);
      deliver(id, reply(f.op, f.t));
    }
  };
  const request = (op, id, a64, b64, text, bytes2) => {
    reap();
    const a = Number(a64);
    const bb = Number(b64);
    if (op === 0) {
      const f = flights.get(id);
      if (f === void 0) return;
      flights.delete(id);
      if (closerOf(f.op) === null) cancel(b, f.t);
      else dropped.push(f);
      return;
    }
    let need = NEEDS[op];
    if (op === OP.OPEN_FILE) need = a === 0 || a === 3 ? GRANT_READ : GRANT_WRITE;
    if (need !== void 0 && grants !== void 0 && (grants & need) === 0) {
      return deliver(id, flat({
        fault: FAULT_NOT_GRANTED,
        text: REFUSED
      }));
    }
    switch (op) {
      case OP.LOAD:
        return deliver(id, load(b, bytes2, a));
      case OP.CALL:
        return deliver(id, call2(a, text, bb));
      case OP.UNLOAD:
        loadedModules.delete(a);
        return deliver(id, flat({}));
      case OP.VALIDATE:
        return deliver(id, validate(bytes2));
      case OP.CAPABILITY: {
        const cap = provides.find((c) => c.name === text);
        const versions = new TextDecoder().decode(bytes2);
        if (cap === void 0) return deliver(id, flat(notProvided(text)));
        if (!versionMatches(cap, versions)) {
          return deliver(id, flat({
            fault: FAULT_UNSUPPORTED,
            text: `${text} ${cap.version} does not satisfy ${versions}`
          }));
        }
        return deliver(id, flat({
          n: BigInt(cap.base),
          m: BigInt(cap.count),
          text: cap.version
        }));
      }
    }
    const provided = provides.some((c) => op >= c.base && op < c.base + c.count);
    const payload = provided ? capRequest(a64, b64, text, bytes2) : payloadOf(op, a, bb, text, bytes2);
    if (payload === null) {
      return deliver(id, flat({
        fault: FAULT_UNSUPPORTED,
        text: `this host serves no request ${op}`
      }));
    }
    if (AT_ONCE.has(op)) {
      let f;
      try {
        f = answerOf(op, hostCall(b, op, payload));
      } catch (e) {
        f = failure(e);
      }
      return deliver(id, f);
    }
    let t;
    try {
      t = submit(b, op, payload);
    } catch (e) {
      return deliver(id, failure(e));
    }
    flights.set(id, {
      op,
      t
    });
  };
  const waitAny2 = (ids, millis) => {
    reap();
    const want2 = Array.from(ids);
    const gone2 = want2.findIndex((id) => !flights.has(id));
    if (gone2 >= 0) return gone2;
    const tickets = want2.map((id) => flights.get(id).t);
    const woke = waitAny(b, tickets, millis);
    deliverReady(want2);
    if (woke === null) return -1;
    return tickets.findIndex((t) => t.id === woke.id);
  };
  const exitWith = (code) => {
    throw new WacExit(code);
  };
  const interrupted = () => readI32le(hostCall(b, OP.ASK_INTERRUPT, EMPTY4)) !== 0;
  h = make(request, waitAny2, exitWith, interrupted);
  return h;
}
function mainArgs(b, app, provides = []) {
  const h = hostFor(b, app, void 0, provides);
  return h === void 0 ? [] : [
    h
  ];
}
function callMain(b, app, args) {
  const code = app.main(...args);
  if (args.length === 1) {
    const ask = app.__wacOutstanding;
    if (typeof ask !== "function") {
      throw new Error("the module exports no `__wacOutstanding`, so its unfinished work cannot be asked about");
    }
    const left = Number(ask(args[0]));
    if (left > 0) {
      const said = `wac: finished with ${left} continuation(s) still waiting \u2014 call \`sys.drain()\` to run them
`;
      hostCall(b, OP.WRITE_STDERR, new TextEncoder().encode(said));
      return 1;
    }
  }
  return code;
}

// ../wac-e2/packages/platform/host/entryBrowser.ts
function runAsWorkerBrowser(load2) {
  const scope = self;
  scope.postMessage({
    ready: true
  });
  scope.onmessage = (ev) => {
    const start = ev.data;
    void (async () => {
      const b = bridgeOf(start.sab);
      try {
        const app = await load2();
        const asApp = app;
        const code = callMain(b, asApp, mainArgs(b, asApp, start.provides ?? []));
        scope.postMessage({
          ok: true,
          code
        });
      } catch (e) {
        if (e instanceof WacExit) {
          scope.postMessage({
            ok: true,
            code: e.code
          });
          return;
        }
        scope.postMessage({
          ok: false,
          error: e instanceof Error ? `${e.message}
${e.stack ?? ""}` : String(e)
        });
      }
    })();
  };
}

// ../../../../../wac-app/worker.ts
runAsWorkerBrowser(async () => {
  const res = await fetch(new URL("app.wasm", import.meta.url));
  if (!res.ok) throw new Error("app.wasm: " + res.status);
  globalThis.__wacWasm = new Uint8Array(await res.arrayBuffer());
  return await Promise.resolve().then(() => (init_app_gen(), app_gen_exports));
});
