// ../g/wac-new/packages/platform/host/layout.ts
var SLOTS = 128;
var BUFS = 8;
var INLINE_BYTES = 4096;
var BUF_BYTES = 1 << 17;
var CHUNK = 1 << 16;
var SUBMIT_SEQ = 0;
var DONE_SEQ = 1;
var HOST_GONE = 2;
var CTRL_HEAD = 3;
var SLOT_INTS = 8;
var S_STATUS = 0;
var S_OP = 1;
var S_REQ_LEN = 2;
var S_RES_LEN = 3;
var S_RES_STATUS = 4;
var S_ID = 5;
var S_REQ_BUF = 6;
var S_RES_BUF = 7;
var ST_FREE = 0;
var ST_PENDING = 1;
var ST_RUNNING = 2;
var ST_READY = 3;
var ST_ANSWERING = 4;
var ST_CLAIMED = 5;
var STATUS_OK = 0;
var STATUS_ERR = 1;
var STATUS_MORE = 2;
var STATUS_ACK = 3;
var OP_CONTINUE = -1;
var OP_PUSH = -2;
var OP_ANSWER = -3;
var REQ_FREE_AT = CTRL_HEAD;
var RES_FREE_AT = REQ_FREE_AT + BUFS;
var SLOTS_AT = RES_FREE_AT + BUFS;
var CTRL_INTS = SLOTS_AT + SLOTS * SLOT_INTS;
var CTRL_BYTES = CTRL_INTS * 4;
var REQ_OFFSET = CTRL_BYTES;
var RES_OFFSET = REQ_OFFSET + BUFS * BUF_BYTES;
var INLINE_OFFSET = RES_OFFSET + BUFS * BUF_BYTES;
var TOTAL_BYTES = INLINE_OFFSET + SLOTS * INLINE_BYTES;
function acquireBuf(b, dir) {
  const base = dir === "req" ? REQ_FREE_AT : RES_FREE_AT;
  for (let i = 0; i < BUFS; i++) {
    if (Atomics.compareExchange(b.ctrl, base + i, 0, 1) === 0) return i;
  }
  return -1;
}
function releaseBuf(b, dir, i) {
  if (i < 0) return;
  Atomics.store(b.ctrl, (dir === "req" ? REQ_FREE_AT : RES_FREE_AT) + i, 0);
}
function attach(b, at, field, i) {
  Atomics.store(b.ctrl, at + field, i + 1);
}
function attached(b, at, field) {
  return Atomics.load(b.ctrl, at + field) - 1;
}
function detach(b, at, field) {
  return Atomics.exchange(b.ctrl, at + field, 0) - 1;
}
function slotAt(i) {
  return SLOTS_AT + i * SLOT_INTS;
}
function bridgeOf(sab) {
  const ctrl = new Int32Array(sab, 0, CTRL_INTS);
  const reqs = [];
  const ress = [];
  for (let i = 0; i < BUFS; i++) {
    reqs.push(new Uint8Array(sab, REQ_OFFSET + i * BUF_BYTES, BUF_BYTES));
    ress.push(new Uint8Array(sab, RES_OFFSET + i * BUF_BYTES, BUF_BYTES));
  }
  const inlines = [];
  for (let i = 0; i < SLOTS; i++) {
    inlines.push(new Uint8Array(sab, INLINE_OFFSET + i * INLINE_BYTES, INLINE_BYTES));
  }
  const b = {
    sab,
    ctrl,
    reqBuf: (i) => reqs[i],
    resBuf: (i) => ress[i],
    inline: (i) => inlines[i],
    rebind: (next) => {
      b.sab = next;
      b.ctrl = new Int32Array(next, 0, CTRL_INTS);
      for (let i = 0; i < BUFS; i++) {
        reqs[i] = new Uint8Array(next, REQ_OFFSET + i * BUF_BYTES, BUF_BYTES);
        ress[i] = new Uint8Array(next, RES_OFFSET + i * BUF_BYTES, BUF_BYTES);
      }
      for (let i = 0; i < SLOTS; i++) {
        inlines[i] = new Uint8Array(next, INLINE_OFFSET + i * INLINE_BYTES, INLINE_BYTES);
      }
    }
  };
  return b;
}
function newBridge() {
  return bridgeOf(new SharedArrayBuffer(TOTAL_BYTES));
}

// ../g/wac-new/packages/platform/host/faults.ts
var FAULT_NONE = 0;
var FAULT_NOT_FOUND = 1;
var FAULT_DENIED = 2;
var FAULT_EXISTS = 3;
var FAULT_NOT_EMPTY = 4;
var FAULT_OTHER = 5;
var FAULT_NOT_REPRESENTABLE = 6;
var FAULT_NOT_GRANTED = 7;
var FAULT_IS_DIR = 8;
var FAULT_UNSUPPORTED = 9;
var FAULT_NOT_A_DIR = 10;
var FAULT_READ_ONLY = 11;
var FAULT_NAME_TOO_LONG = 12;
var FAULT_LOOP = 13;
var FAULT_NO_SPACE = 14;
var FAULT_REFUSED = 15;
var FAULT_UNREACHABLE = 16;
var FAULT_TIMED_OUT = 17;
var Faulted = class extends Error {
  fault;
  constructor(fault, message) {
    super(message);
    this.name = "Faulted";
    this.fault = fault;
  }
};
function faultOf(e) {
  if (e instanceof Faulted) return e.fault;
  const denoErrors = globalThis.Deno?.errors;
  if (denoErrors !== void 0) {
    if (isInstance(e, denoErrors.NotFound)) return FAULT_NOT_FOUND;
    if (isInstance(e, denoErrors.PermissionDenied)) return FAULT_DENIED;
    if (isInstance(e, denoErrors.AlreadyExists)) return FAULT_EXISTS;
    if (isInstance(e, denoErrors.NotCapable)) return FAULT_NOT_GRANTED;
    if (isInstance(e, denoErrors.NotADirectory)) return FAULT_NOT_A_DIR;
  }
  const code = e.code;
  if (typeof code === "string") {
    if (code === "ENOENT") return FAULT_NOT_FOUND;
    if (code === "EACCES" || code === "EPERM") return FAULT_DENIED;
    if (code === "EEXIST") return FAULT_EXISTS;
    if (code === "ENOTEMPTY") return FAULT_NOT_EMPTY;
    if (code === "EISDIR") return FAULT_IS_DIR;
    if (code === "ENOTDIR") return FAULT_NOT_A_DIR;
    if (code === "EROFS") return FAULT_READ_ONLY;
    if (code === "ENAMETOOLONG") return FAULT_NAME_TOO_LONG;
    if (code === "ELOOP") return FAULT_LOOP;
    if (code === "ENOSPC") return FAULT_NO_SPACE;
  }
  const name = e.name;
  if (typeof name === "string") {
    if (name === "NotFoundError") return FAULT_NOT_FOUND;
    if (name === "NotAllowedError" || name === "NoModificationAllowedError" || name === "SecurityError") {
      return FAULT_DENIED;
    }
    if (name === "InvalidModificationError") return FAULT_NOT_EMPTY;
  }
  const message = e instanceof Error ? e.message : String(e);
  if (/not empty|os error 39|os error 66/i.test(message)) return FAULT_NOT_EMPTY;
  if (/is a directory|os error 21/i.test(message)) return FAULT_IS_DIR;
  if (/not a directory|os error 20/i.test(message)) return FAULT_NOT_A_DIR;
  if (/read-only file system|os error 30/i.test(message)) return FAULT_READ_ONLY;
  if (/file name too long|os error 36/i.test(message)) return FAULT_NAME_TOO_LONG;
  if (/too many levels of symbolic links|os error 40/i.test(message)) return FAULT_LOOP;
  if (/no space left on device|os error 28/i.test(message)) return FAULT_NO_SPACE;
  if (/not granted/i.test(message)) return FAULT_NOT_GRANTED;
  return FAULT_OTHER;
}
function faultedBytes(fault, message) {
  return changeBytes(fault, message);
}
function changeBytes(fault, message) {
  const text = new TextEncoder().encode(message);
  const out2 = new Uint8Array(text.length + 1);
  out2[0] = fault;
  out2.set(text, 1);
  return out2;
}
function execBytes(status, stdout, stderr, error) {
  const text = new TextEncoder().encode(error);
  const out2 = new Uint8Array(12 + stdout.length + stderr.length + text.length);
  const dv = new DataView(out2.buffer);
  dv.setInt32(0, status, true);
  dv.setInt32(4, stdout.length, true);
  dv.setInt32(8, stderr.length, true);
  out2.set(stdout, 12);
  out2.set(stderr, 12 + stdout.length);
  out2.set(text, 12 + stdout.length + stderr.length);
  return out2;
}
var CHANGED_OK = new Uint8Array([
  FAULT_NONE
]);
function phraseOf(fault) {
  if (fault === FAULT_NOT_FOUND) return "No such file or directory";
  if (fault === FAULT_DENIED) return "Permission denied";
  if (fault === FAULT_EXISTS) return "File exists";
  if (fault === FAULT_NOT_EMPTY) return "Directory not empty";
  if (fault === FAULT_IS_DIR) return "Is a directory";
  if (fault === FAULT_NOT_A_DIR) return "Not a directory";
  if (fault === FAULT_READ_ONLY) return "Read-only file system";
  if (fault === FAULT_NAME_TOO_LONG) return "File name too long";
  if (fault === FAULT_LOOP) return "Too many levels of symbolic links";
  if (fault === FAULT_NO_SPACE) return "No space left on device";
  if (fault === FAULT_REFUSED) return "Connection refused";
  if (fault === FAULT_UNREACHABLE) return "No route to host";
  if (fault === FAULT_TIMED_OUT) return "Connection timed out";
  if (fault === FAULT_NOT_REPRESENTABLE) return "the name is not representable on this host";
  if (fault === FAULT_NOT_GRANTED) return "not granted to this application";
  return "";
}
async function changed(work, describe = (_, m) => m) {
  try {
    await work();
    return CHANGED_OK;
  } catch (e) {
    const fault = faultOf(e);
    return changeBytes(fault, describe(fault, e instanceof Error ? e.message : String(e)));
  }
}
function isInstance(e, ctor) {
  return typeof ctor === "function" && e instanceof ctor;
}
var STAT_BYTES = 26;
var STAT_FAULT = 20;

// ../g/wac-new/packages/platform/host/ops.ts
var OP = {
  NOW_MILLIS: 1,
  MONOTONIC_NANOS: 2,
  RANDOM_BYTES: 3,
  // 4 and 5 were `LOG` and `WARN`, lines a host printed for the program. Retired rather than reused: a line is
  // bytes on standard output or error, `WRITE_STDOUT` and `WRITE_STDERR` (design/system/0013 step 6).
  ARG_COUNT: 6,
  ARG: 7,
  ENV: 8,
  READ_FILE: 9,
  WRITE_FILE: 10,
  READ_STDIN: 11,
  WRITE_STDOUT: 12,
  STAT: 13,
  READ_DIR: 14,
  MKDIR: 15,
  REMOVE: 16,
  RENAME: 17,
  // 18 and 20 were `OPEN_INPUT` and `OPEN_OUTPUT`, which redirected standard input and output to a
  // file. Retired with `Cli` rather than reused (design/system/0013 step 6): a program streams a file
  // through `OPEN_FILE`.
  READ_CHUNK: 19,
  CONNECT: 21,
  LISTEN: 22,
  ACCEPT: 23,
  RECV: 24,
  SEND: 25,
  CLOSE_SOCKET: 26,
  SPAWN: 27,
  EXIT_CODE: 28,
  /** How a child ended — `Child.ended()`: how (0 exited, 1 trapped, 2 a host limit), the code or trap kind, and what was said. */
  CHILD_ENDED: 74,
  CLOSE_FEED: 29,
  SLEEP_MILLIS: 30,
  // 31–40 were std's `Page` — render, text, values, events, title, pixels, files, downloads — and
  // 51 and 56 its style and partial blit. Retired rather than reused: a page is `web`'s
  // `main(Page)` now, which talks to the document by messages and needs no bridge
  // (design/system/0011 step 7).
  CWD: 41,
  // 42 and 43 were `PUSH_CHILD` and `POP_CHILD`, an applet run in process as a frame. Retired with
  // `Cli` rather than reused (design/system/0013 step 6): nothing called them but `Cli`'s own fields.
  // 44 was `EXEC`, the same capability without an environment or a choice about the child's streams.
  // Retired rather than reused — see `EXEC_WITH` at the end.
  // 45 was `OUTPUT_ERROR`, why a write to an `OPEN_OUTPUT` file failed; it went with that.
  LINK_STAT: 47,
  WRITE_STDERR: 48,
  SPAWN_SELF: 49,
  /**
   * "Has the user asked to interrupt?" — `Host.interrupted` in `std/platform.wac`.
   *
   * Answered from what the host already knows, so it starts nothing; it still parks the worker like
   * every opcode, and that is the point rather than the cost — see the note in `provider.ts`.
   */
  ASK_INTERRUPT: 50,
  /**
   * "Make this file executable, or stop it being" — `Files.setExecutable` in `std/platform.wac`.
   *
   * One bit rather than a mode, because git's regular-file modes differ only in that bit and because a
   * browser's OPFS has no mode bits at all, so a general `chmod` would be unanswerable on one of the four
   * hosts rather than merely unsupported on it.
   */
  SET_EXECUTABLE: 52,
  // **Datagrams**, which are not `connect`/`recv`/`send` with a flag. A QUIC server answers many
  // peers from one socket and a connection is identified by its connection ID rather than by an
  // address, so a peer may move mid-connection; a connected socket represents neither. See
  // design/system 0007. `CLOSE_SOCKET` closes one of these too — a handle is a handle.
  BIND_DATAGRAM: 53,
  RECEIVE_FROM: 54,
  SEND_TO: 55,
  /**
   * End a socket's outbound direction and keep reading — `issues/system/0215`.
   *
   * Its own opcode rather than a flag on `CLOSE_SOCKET`, because a host that did not know about the
   * flag would close both directions and the program would hang on a reply that can never come. An
   * unserved opcode fails and names itself.
   */
  CLOSE_SEND: 57,
  /**
   * `Procs.exec` — a host program, run to completion, in a directory. `issues/system/0165`, `0290b`.
   *
   * **44 and 58 were earlier spellings of it, and are not reused**: a binary or a worker bundle built
   * before still sends them and should fail rather than be misread — a host that had not been rebuilt
   * would read the environment or the directory as the head of standard input, silently, where an
   * opcode it does not serve fails and names itself. They are not listed here because
   * `conformance_test.wac` reads this table as *the surface*.
   */
  EXEC: 59,
  /**
   * "Set this file's permission bits" — `Files.chmod` in `std/platform.wac`.
   *
   * `SET_EXECUTABLE` above is the narrow form and stays: it promises one bit and changes one bit,
   * which is what a git checkout wants. This promises the mode. `issues/system/0296c`.
   */
  CHMOD: 60,
  OPEN_FILE: 61,
  CLOSE_FILE: 62,
  CLOSE_OUTPUT: 63,
  // **Answered in the worker's own realm and never sent to the launcher**: a loaded module lives in
  // the caller's realm, its requests served over the caller's own bridge, so nothing about it crosses.
  // Numbered because std asks for them like any other request. `issues/system/0240c`.
  LOAD: 64,
  CALL: 65,
  UNLOAD: 66,
  VALIDATE: 67,
  // A capability by name: `wac.http` in a page that was granted the network (`hosthttp.ts`), none elsewhere; a parent
  // serving a child answers its lookups itself.
  CAPABILITY: 68,
  /**
   * A file opened with `OPEN_FILE` how 3 (read anywhere) or 4 (read and write anywhere, created if absent and never
   * emptied) — `Files.openRandom`. Each names its handle first. `READ_AT`: offset, length → the bytes there.
   */
  READ_AT: 69,
  /** Offset, bytes: written there, the file growing as it needs to. */
  WRITE_AT: 70,
  /** → the file's size. */
  FILE_SIZE: 71,
  /** The size to cut or grow it to. */
  TRUNCATE_FILE: 72,
  /** What was written is on the disk before this answers: `fsync`. */
  SYNC_FILE: 73
};
var GRANT_READ = 1;
var GRANT_WRITE = 2;
var GRANT_NET = 4;
var GRANT_ENV = 8;
var GRANT_RUN = 16;

// ../g/wac-new/packages/platform/host/schedule.ts
function policyOf() {
  let raw2 = "";
  try {
    raw2 = Deno.env.get("WAC_SCHED") ?? "";
  } catch {
    return {
      policy: "off",
      seed: 0
    };
  }
  if (raw2 === "off") return {
    policy: "off",
    seed: 0
  };
  if (raw2 === "fifo") return {
    policy: "fifo",
    seed: 0
  };
  const m = /^seed(?:=(\d+))?$/.exec(raw2);
  if (m !== null) return {
    policy: "seeded",
    seed: m[1] === void 0 ? DEFAULT_SEED : Number(m[1])
  };
  return {
    policy: "off",
    seed: 0
  };
}
var DEFAULT_SEED = 20260806;
var IDLE_MS = 5;
function rng(seed) {
  let x = seed || 1;
  return () => {
    x ^= x << 13;
    x >>>= 0;
    x ^= x >>> 17;
    x ^= x << 5;
    x >>>= 0;
    return x;
  };
}
var Scheduler = class {
  #policy;
  #next;
  #ready = [];
  #seq = 0;
  #log = [];
  constructor(policy, seed) {
    this.#policy = policy;
    this.#next = rng(seed);
  }
  get on() {
    return this.#policy !== "off";
  }
  /** The choices made, oldest first, for a run that has to be explained or replayed. */
  get log() {
    return this.#log;
  }
  /**
   * An answer is ready.
   *
   * With scheduling off this writes it immediately, which is what the host has always done. With it on,
   * the answer joins the ready set and is delivered when this scheduler says.
   */
  ready(bridge, call, deliver) {
    if (this.#policy === "off") {
      deliver();
      return;
    }
    this.#ready.push({
      bridge,
      call,
      seq: this.#seq++,
      deliver
    });
    this.#pump();
  }
  /**
   * A bridge is running: it has been answered and has not yet come back.
   *
   * This is what "one worker at a time" is made of. A worker runs from the moment its answer lands until
   * it submits its next call or finishes, and while any worker is in that state no other is answered —
   * so two guests are never executing at once, whatever the operating system would have allowed.
   */
  #running = /* @__PURE__ */ new Set();
  /** Cleared by `respond.ts` when a sweep sees this bridge submit again, or when it stops. */
  quiet(bridge) {
    if (!this.#running.delete(bridge)) return;
    this.#pump();
  }
  /**
   * Deliver at most one answer, to at most one worker.
   *
   * **Event-driven rather than timed.** The first version put a `setTimeout(0)` between deliveries as a
   * proxy for "wait until the worker comes back", which costs a millisecond of the event loop on *every
   * host call* — a program making fifty thousand of them would pay a minute for it. The proxy is not
   * needed: the responder already wakes when a worker submits, and that is exactly the signal that the
   * worker has gone quiet again.
   *
   * The one case with no such signal is a worker that finishes without submitting anything more. Its
   * result message is delivered elsewhere (`children.ts`), so a hurry-up timer covers it: if nothing has
   * come back within `IDLE_MS`, the mark is dropped and the next answer goes out. That clock cannot
   * decide anything — the worst it does is allow an ordering the policy did not choose, which is the
   * behaviour without a scheduler at all.
   */
  #pump() {
    if (this.#ready.length === 0) return;
    if (this.#running.size > 0) {
      this.#armIdle();
      return;
    }
    const at = this.#choose();
    if (at < 0) return;
    const [chosen] = this.#ready.splice(at, 1);
    this.#log.push(`${chosen.bridge}:${chosen.call}@${chosen.seq}`);
    this.#running.add(chosen.bridge);
    chosen.deliver();
    this.#armIdle();
  }
  #idle = null;
  /** The hurry-up, armed only while something is waiting. Never more than one outstanding. */
  #armIdle() {
    if (this.#idle !== null || this.#running.size === 0) return;
    this.#idle = setTimeout(() => {
      this.#idle = null;
      this.#running.clear();
      this.#pump();
    }, IDLE_MS);
    Deno.unrefTimer(this.#idle);
  }
  /** Which of the ready answers goes next. The whole of the policy is here. */
  #choose() {
    if (this.#ready.length === 0) return -1;
    if (this.#policy === "fifo") {
      let best = 0;
      for (let i = 1; i < this.#ready.length; i++) {
        if (this.#ready[i].seq < this.#ready[best].seq) best = i;
      }
      return best;
    }
    return this.#next() % this.#ready.length;
  }
  /**
   * Every bridge in this process, and how to describe it.
   *
   * A stall is almost never explainable from one bridge: a shell parked reading a child says nothing
   * about what the *child* is doing, and that is where a cycle closes. The scheduler already has to know
   * about every bridge, so it is the natural place to ask them all at once.
   */
  #bridges = /* @__PURE__ */ new Map();
  register(bridge, describe) {
    this.#bridges.set(bridge, describe);
  }
  forget(bridge) {
    this.#bridges.delete(bridge);
  }
  /** Every live bridge's state, for a caller explaining a stall. Reads only, and never throws. */
  survey() {
    const lines = [];
    for (const [id, describe] of this.#bridges) {
      try {
        lines.push(`    bridge ${id}: ${describe()}`);
      } catch {
        lines.push(`    bridge ${id}: <gone>`);
      }
    }
    return lines.join("\n");
  }
};
var shared = null;
function scheduler() {
  if (shared === null) {
    const { policy, seed } = policyOf();
    shared = new Scheduler(policy, seed);
  }
  return shared;
}

// ../g/wac-new/packages/platform/host/call.ts
var enc = new TextEncoder();
var dec = new TextDecoder();
var OP_NAMES = Object.fromEntries(Object.entries(OP).map(([name, op]) => [
  op,
  name
]));
var opName = (op) => op === OP_CONTINUE ? "a continued response" : OP_NAMES[op] ?? `op ${op}`;
var DETAILED = 12;
function describeSlots(b) {
  const names = {
    [ST_FREE]: "free",
    [ST_PENDING]: "pending",
    [ST_RUNNING]: "running",
    [ST_READY]: "ready",
    [ST_ANSWERING]: "answering",
    [ST_CLAIMED]: "claimed"
  };
  const busy = [];
  const rest = /* @__PURE__ */ new Map();
  for (let i = 0; i < SLOTS; i++) {
    const at = slotAt(i);
    const st = Atomics.load(b.ctrl, at + S_STATUS);
    if (st === ST_FREE) continue;
    const op = Atomics.load(b.ctrl, at + S_OP);
    const rb = attached(b, at, S_REQ_BUF);
    const handle = (op === OP.RECV || op === OP.SEND) && rb >= 0 && Atomics.load(b.ctrl, at + S_REQ_LEN) >= 4 ? `(h=${new DataView(b.reqBuf(rb).buffer, b.reqBuf(rb).byteOffset, 4).getInt32(0, true)})` : "";
    const what = `${names[st] ?? st}:${opName(op)}${handle}`;
    if (busy.length < DETAILED) busy.push(`${i}:${what}`);
    else rest.set(what, (rest.get(what) ?? 0) + 1);
  }
  const counters = `(submit=${Atomics.load(b.ctrl, SUBMIT_SEQ)} done=${Atomics.load(b.ctrl, DONE_SEQ)})`;
  if (busy.length === 0) return `no slot in use ${counters}`;
  const more = [
    ...rest
  ].sort((x, y) => y[1] - x[1]).map(([w, n]) => `${w} \xD7 ${n}`);
  return `${busy.join(" ")}${more.length === 0 ? "" : ` and ${more.join(" ")}`} ${counters}`;
}
var str = (s) => enc.encode(s);
var argBytes = (a) => typeof a === "string" ? enc.encode(a) : a;
var EMPTY_ARG = new Uint8Array(0);
var unstr = (b) => dec.decode(b);
function i32le(n) {
  const b = new Uint8Array(4);
  new DataView(b.buffer).setInt32(0, n, true);
  return b;
}
function readI32le(b, at = 0) {
  return new DataView(b.buffer, b.byteOffset, b.byteLength).getInt32(at, true);
}
function i64le(n) {
  const b = new Uint8Array(8);
  new DataView(b.buffer).setBigInt64(0, n, true);
  return b;
}
function readI64le(b, at = 0) {
  return new DataView(b.buffer, b.byteOffset, b.byteLength).getBigInt64(at, true);
}

// ../g/wac-new/packages/platform/host/respond.ts
var EMPTY = new Uint8Array(0);
var nextBridgeId = 0;
function joined(parts, last) {
  const total = parts.reduce((n, p) => n + p.length, 0) + last.length;
  const out2 = new Uint8Array(total);
  let at = 0;
  for (const p of parts) {
    out2.set(p, at);
    at += p.length;
  }
  out2.set(last, at);
  return out2;
}
function serveHostCalls(b, handlers, opts = {}) {
  let running = true;
  const sched = opts.scheduler ?? scheduler();
  const bridgeId = nextBridgeId++;
  sched.register(bridgeId, () => `${running ? "" : "responder stopped \u2014 "}${describeSlots(b)}` + (handling.size > 0 ? ` handling ${describeHandling()}` : "") + (outbox.length > 0 ? ` and ${outbox.length} answer(s) waiting for a free slot` : ""));
  const tails = /* @__PURE__ */ new Map();
  const partial = Array.from({
    length: SLOTS
  }, () => []);
  const outbox = [];
  const handling = /* @__PURE__ */ new Map();
  const describeHandling = () => {
    const tally = /* @__PURE__ */ new Map();
    for (const w of handling.values()) tally.set(w, (tally.get(w) ?? 0) + 1);
    return [
      ...tally
    ].map(([w, n]) => `${w} \xD7 ${n}`).join(", ");
  };
  const write = (slot, id, op, status, body) => {
    const at = slotAt(slot);
    const bi = body.length > INLINE_BYTES ? acquireBuf(b, "res") : -1;
    const room = bi >= 0 ? b.resBuf(bi) : b.inline(slot);
    const fits = Math.min(body.length, room.length);
    const tail = body.subarray(fits);
    room.set(body.subarray(0, fits), 0);
    attach(b, at, S_RES_BUF, bi);
    Atomics.store(b.ctrl, at + S_RES_LEN, fits);
    Atomics.store(b.ctrl, at + S_RES_STATUS, tail.length > 0 ? STATUS_MORE : status);
    if (tail.length > 0) tails.set(id, {
      tail,
      status
    });
    Atomics.store(b.ctrl, at + S_ID, id);
    Atomics.store(b.ctrl, at + S_OP, op);
    Atomics.store(b.ctrl, at + S_STATUS, ST_READY);
    Atomics.add(b.ctrl, DONE_SEQ, 1);
    Atomics.notify(b.ctrl, DONE_SEQ);
  };
  let next = 0;
  const flush = () => {
    while (outbox.length > 0) {
      let slot = -1;
      for (let k = 0; k < SLOTS && slot < 0; k++) {
        const i = (next + k) % SLOTS;
        if (Atomics.compareExchange(b.ctrl, slotAt(i) + S_STATUS, ST_FREE, ST_ANSWERING) === ST_FREE) slot = i;
      }
      if (slot < 0) return;
      next = (slot + 1) % SLOTS;
      const a = outbox.shift();
      write(slot, a.id, OP_ANSWER, a.status, a.body);
    }
  };
  const answer = (id, status, body) => {
    sched.ready(bridgeId, id, () => {
      outbox.push({
        id,
        status,
        body
      });
      flush();
    });
  };
  const inPlace = (slot, id, op, status, body) => {
    sched.ready(bridgeId, id, () => write(slot, id, op, status, body));
  };
  const take2 = (slot) => {
    const at = slotAt(slot);
    const op = Atomics.load(b.ctrl, at + S_OP);
    const len = Atomics.load(b.ctrl, at + S_REQ_LEN);
    const id = Atomics.load(b.ctrl, at + S_ID);
    const rb = detach(b, at, S_REQ_BUF);
    const payload = rb < 0 ? EMPTY : b.reqBuf(rb).slice(0, len);
    releaseBuf(b, "req", rb);
    if (Atomics.compareExchange(b.ctrl, at + S_STATUS, ST_PENDING, ST_RUNNING) !== ST_PENDING) return;
    if (op === OP_CONTINUE) {
      const held = tails.get(id);
      tails.delete(id);
      inPlace(slot, id, OP_CONTINUE, held?.status ?? STATUS_OK, held?.tail ?? EMPTY);
      return;
    }
    if (op === OP_PUSH) {
      partial[slot].push(payload);
      inPlace(slot, id, OP_PUSH, STATUS_ACK, EMPTY);
      return;
    }
    let whole = payload;
    if (partial[slot].length > 0) {
      whole = joined(partial[slot], payload);
      partial[slot] = [];
    }
    Atomics.store(b.ctrl, at + S_STATUS, ST_FREE);
    Atomics.add(b.ctrl, DONE_SEQ, 1);
    Atomics.notify(b.ctrl, DONE_SEQ);
    const h = handlers[op];
    if (h === void 0) {
      answer(id, STATUS_ERR, faultedBytes(FAULT_OTHER, `no handler for capability ${op}`));
      return;
    }
    const handle = (op === OP.RECV || op === OP.SEND) && whole.length >= 4 ? `(h=${new DataView(whole.buffer, whole.byteOffset, 4).getInt32(0, true)})` : "";
    handling.set(id, `${opName(op)}${handle}`);
    void (async () => {
      try {
        answer(id, STATUS_OK, await h(whole));
      } catch (e) {
        answer(id, STATUS_ERR, faultedBytes(faultOf(e), e instanceof Error ? e.message : String(e)));
      } finally {
        handling.delete(id);
      }
    })();
  };
  let sweeps = 0;
  const failPending = (why) => {
    Atomics.store(b.ctrl, HOST_GONE, 1);
    for (let s = 0; s < SLOTS; s++) {
      const at = slotAt(s);
      const st = Atomics.load(b.ctrl, at + S_STATUS);
      if (st === ST_PENDING) {
        if (Atomics.compareExchange(b.ctrl, at + S_STATUS, ST_PENDING, ST_RUNNING) !== ST_PENDING) continue;
        releaseBuf(b, "req", detach(b, at, S_REQ_BUF));
      } else if (st !== ST_RUNNING) {
        continue;
      }
      try {
        const op = Atomics.load(b.ctrl, at + S_OP);
        write(s, Atomics.load(b.ctrl, at + S_ID), op === OP_PUSH ? OP_PUSH : OP_ANSWER, STATUS_ERR, faultedBytes(FAULT_OTHER, why));
      } catch {
      }
    }
    Atomics.add(b.ctrl, DONE_SEQ, 1);
    Atomics.notify(b.ctrl, DONE_SEQ);
  };
  const loop = async () => {
    while (running && !opts.signal?.aborted) {
      const seen = Atomics.load(b.ctrl, SUBMIT_SEQ);
      for (let s = 0; s < SLOTS; s++) {
        if (Atomics.load(b.ctrl, slotAt(s) + S_STATUS) === ST_PENDING) take2(s);
      }
      flush();
      sweeps++;
      sched.quiet(bridgeId);
      const w = Atomics.waitAsync(b.ctrl, SUBMIT_SEQ, seen);
      if (w.async) await w.value;
      if (!running || opts.signal?.aborted) return;
    }
  };
  const done = loop().catch((e) => {
    const why = `the host responder stopped: ${e instanceof Error ? e.message : String(e)}`;
    try {
      console.error(`wac: ${why}`);
    } catch {
    }
    failPending(why);
    throw e;
  });
  return {
    /**
     * Whether the loop is still going, how many sweeps it has made, and which handlers have not come
     * back ("" for none). For a caller narrating a stall.
     */
    stats() {
      return {
        running,
        sweeps,
        handling: describeHandling()
      };
    },
    stop() {
      running = false;
      failPending("the host responder was stopped");
      sched.quiet(bridgeId);
      sched.forget(bridgeId);
      Atomics.add(b.ctrl, SUBMIT_SEQ, 1);
      Atomics.notify(b.ctrl, SUBMIT_SEQ);
    },
    done
  };
}

// ../g/wac-new/packages/platform/host/entropy.ts
var PER_CALL = 65536;
var MOST = 1 << 20;
function randomBytes(n) {
  if (n < 0 || n > MOST) throw new Error(`randomBytes(${n}) out of range`);
  const out2 = new Uint8Array(n);
  for (let at = 0; at < n; at += PER_CALL) {
    crypto.getRandomValues(out2.subarray(at, Math.min(at + PER_CALL, n)));
  }
  return out2;
}

// ../g/wac-new/packages/platform/host/child.ts
function joinPath(cwd, path) {
  if (cwd === "" || path.startsWith("/")) return path;
  if (path === "") return cwd;
  return cwd.endsWith("/") ? cwd + path : cwd + "/" + path;
}

// ../g/wac-new/packages/platform/host/hosthttp.ts
var HOST_HTTP = {
  name: "wac.http",
  version: "1.0.0",
  base: 4096,
  count: 3
};
var HTTP_OPEN = HOST_HTTP.base;
var HTTP_READ = HOST_HTTP.base + 1;
var HTTP_CLOSE = HOST_HTTP.base + 2;
var FAULT_OTHER2 = 5;
var FAULT_UNREACHABLE2 = 16;
var FAULT_TIMED_OUT2 = 17;
var enc2 = new TextEncoder();
var dec2 = new TextDecoder();
function readCapRequest(p) {
  const tl = readI32le(p, 16);
  return {
    a: readI64le(p, 0),
    b: readI64le(p, 8),
    text: dec2.decode(p.subarray(20, 20 + tl)),
    bytes: p.slice(20 + tl)
  };
}
function capAnswer(x) {
  const t = enc2.encode(x.text ?? "");
  const bytes = x.bytes ?? new Uint8Array(0);
  const out2 = new Uint8Array(24 + t.length + bytes.length);
  out2.set(i64le(x.n ?? 0n), 0);
  out2.set(i64le(x.m ?? 0n), 8);
  out2.set(i32le(x.flags ?? 0), 16);
  out2.set(i32le(t.length), 20);
  out2.set(t, 24);
  out2.set(bytes, 24 + t.length);
  return out2;
}
var FORBIDDEN = /* @__PURE__ */ new Set([
  "accept-charset",
  "accept-encoding",
  "access-control-request-headers",
  "access-control-request-method",
  "connection",
  "content-length",
  "cookie",
  "cookie2",
  "date",
  "dnt",
  "expect",
  "host",
  "keep-alive",
  "origin",
  "referer",
  "set-cookie",
  "te",
  "trailer",
  "transfer-encoding",
  "upgrade",
  "via"
]);
var forbidden = (name) => {
  const n = name.toLowerCase();
  return FORBIDDEN.has(n) || n.startsWith("proxy-") || n.startsWith("sec-");
};
function splitHead(bytes) {
  let end = -1;
  for (let i = 0; i + 1 < bytes.length; i++) {
    if (bytes[i] === 13 && bytes[i + 1] === 10 && (i === 0 || i >= 2 && bytes[i - 2] === 13 && bytes[i - 1] === 10)) {
      end = i;
      break;
    }
  }
  if (end < 0) throw new Faulted(FAULT_OTHER2, "wac.http: a request's header block has no blank line after it");
  const headers = [];
  for (const line2 of dec2.decode(bytes.subarray(0, end)).split("\r\n")) {
    if (line2 === "") continue;
    const colon = line2.indexOf(":");
    if (colon <= 0) throw new Faulted(FAULT_OTHER2, `wac.http: a header line without a name: ${JSON.stringify(line2)}`);
    headers.push([
      line2.slice(0, colon).trim(),
      line2.slice(colon + 1).trim()
    ]);
  }
  return {
    headers,
    body: bytes.slice(end + 2)
  };
}
function httpHandlers(fetchFn = globalThis.fetch.bind(globalThis)) {
  const DEADLINE = "wac.http deadline";
  const ranOut = (abort) => abort.signal.aborted && abort.signal.reason === DEADLINE;
  const finish = (id) => {
    const o = open.get(id);
    if (o !== void 0 && o.timer !== void 0) clearTimeout(o.timer);
    open.delete(id);
  };
  const open = /* @__PURE__ */ new Map();
  let next = 1;
  return {
    [HTTP_OPEN]: async (p) => {
      const q = readCapRequest(p);
      const space = q.text.indexOf(" ");
      if (space <= 0) throw new Faulted(FAULT_OTHER2, `wac.http: open wants "METHOD URL", not ${JSON.stringify(q.text)}`);
      const method = q.text.slice(0, space);
      const url = q.text.slice(space + 1);
      const { headers, body } = splitHead(q.bytes);
      const h = new Headers();
      for (const [name, value] of headers) if (!forbidden(name)) h.append(name, value);
      const abort = new AbortController();
      const ms = Number(q.b);
      const timer = ms >= 0 ? setTimeout(() => abort.abort(DEADLINE), ms) : void 0;
      let res;
      try {
        res = await fetchFn(url, {
          method,
          headers: h,
          // A fresh `ArrayBuffer`, which is what `BodyInit` takes: the request's bytes may be a view of a shared one.
          body: method === "GET" || method === "HEAD" ? void 0 : new Uint8Array(body).buffer,
          redirect: "follow",
          signal: abort.signal
        });
      } catch (e) {
        if (timer !== void 0) clearTimeout(timer);
        if (ranOut(abort)) throw new Faulted(FAULT_TIMED_OUT2, `timed out after ${ms}ms`);
        if (e instanceof TypeError) throw new Faulted(FAULT_UNREACHABLE2, "network error or CORS refusal");
        throw new Faulted(FAULT_OTHER2, `wac.http: ${e instanceof Error ? e.message : String(e)}`);
      }
      const id = next++;
      open.set(id, {
        reader: res.body === null ? null : res.body.getReader(),
        held: new Uint8Array(0),
        abort,
        timer,
        ms
      });
      let lines = "";
      res.headers.forEach((value, name) => {
        lines += `${name}: ${value}\r
`;
      });
      return capAnswer({
        n: BigInt(id),
        m: BigInt(res.status),
        text: res.url || url,
        bytes: enc2.encode(lines)
      });
    },
    [HTTP_READ]: async (p) => {
      const q = readCapRequest(p);
      const o = open.get(Number(q.a));
      if (o === void 0) throw new Faulted(FAULT_OTHER2, `wac.http: no open response ${q.a}`);
      if (o.held.length === 0 && o.reader !== null) {
        let r;
        try {
          r = await o.reader.read();
        } catch (e) {
          finish(Number(q.a));
          if (ranOut(o.abort)) throw new Faulted(FAULT_TIMED_OUT2, `timed out after ${o.ms}ms`);
          throw new Faulted(FAULT_UNREACHABLE2, `wac.http: the body stopped arriving \u2014 ${e instanceof Error ? e.message : String(e)}`);
        }
        if (r.done) {
          finish(Number(q.a));
          return capAnswer({
            flags: 1
          });
        }
        o.held = r.value;
      }
      if (o.held.length === 0) {
        finish(Number(q.a));
        return capAnswer({
          flags: 1
        });
      }
      const piece = o.held.slice(0, CHUNK);
      o.held = o.held.subarray(piece.length);
      return capAnswer({
        bytes: piece
      });
    },
    [HTTP_CLOSE]: (p) => {
      const q = readCapRequest(p);
      const o = open.get(Number(q.a));
      finish(Number(q.a));
      if (o !== void 0) {
        o.abort.abort();
        o.reader?.cancel().catch(() => {
        });
      }
      return Promise.resolve(capAnswer({}));
    }
  };
}

// ../g/wac-new/packages/platform/host/queue.ts
var EMPTY2 = new Uint8Array(0);
function emptyQueue(cap = 0) {
  return {
    cap,
    chunks: [],
    held: 0,
    ended: false,
    reader: null,
    writers: []
  };
}
function join(parts) {
  if (parts.length === 1) return parts[0];
  let n = 0;
  for (const p of parts) n += p.length;
  const out2 = new Uint8Array(n);
  let at = 0;
  for (const p of parts) {
    out2.set(p, at);
    at += p.length;
  }
  return out2;
}
function releaseRoom(state) {
  const chunks = [
    ...state.chunks
  ];
  const writers = [
    ...state.writers
  ];
  const effects = [];
  let held = state.held;
  while (writers.length > 0) {
    const first = writers[0];
    if (state.cap > 0 && held + first.bytes.length > state.cap) break;
    writers.shift();
    chunks.push(first.bytes);
    held += first.bytes.length;
    effects.push({
      to: "writer",
      id: first.id,
      ok: true
    });
  }
  return {
    state: {
      ...state,
      chunks,
      held,
      writers
    },
    effects
  };
}
function take(state, limit) {
  if (state.chunks.length === 0) return {
    state,
    taken: null
  };
  const chunks = [
    ...state.chunks
  ];
  const parts = [];
  let got = 0;
  while (chunks.length > 0 && got < limit) {
    const head = chunks[0];
    if (got + head.length <= limit) {
      chunks.shift();
      parts.push(head);
      got += head.length;
    } else {
      const room = limit - got;
      parts.push(head.subarray(0, room));
      chunks[0] = head.subarray(room);
      got += room;
    }
  }
  return {
    state: {
      ...state,
      chunks,
      held: state.held - got
    },
    taken: join(parts)
  };
}
function apply(state, event) {
  switch (event.kind) {
    case "push": {
      if (state.ended) return {
        state,
        effects: [
          {
            to: "writer",
            id: event.id,
            ok: false
          }
        ]
      };
      if (event.bytes.length === 0) return {
        state,
        effects: [
          {
            to: "writer",
            id: event.id,
            ok: true
          }
        ]
      };
      if (state.reader !== null) {
        return {
          state: {
            ...state,
            reader: null
          },
          effects: [
            {
              to: "reader",
              id: state.reader,
              bytes: event.bytes
            },
            {
              to: "writer",
              id: event.id,
              ok: true
            }
          ]
        };
      }
      if (state.cap > 0 && state.held + event.bytes.length > state.cap) {
        return {
          state: {
            ...state,
            writers: [
              ...state.writers,
              {
                id: event.id,
                bytes: event.bytes
              }
            ]
          },
          effects: []
        };
      }
      return {
        state: {
          ...state,
          chunks: [
            ...state.chunks,
            event.bytes
          ],
          held: state.held + event.bytes.length
        },
        effects: [
          {
            to: "writer",
            id: event.id,
            ok: true
          }
        ]
      };
    }
    case "next": {
      const got = take(state, event.limit);
      if (got.taken !== null) {
        const freed = releaseRoom(got.state);
        return {
          state: freed.state,
          effects: [
            {
              to: "reader",
              id: event.id,
              bytes: got.taken
            },
            ...freed.effects
          ]
        };
      }
      if (state.ended) return {
        state,
        effects: [
          {
            to: "reader",
            id: event.id,
            bytes: EMPTY2
          }
        ]
      };
      const displaced = state.reader === null ? [] : [
        {
          to: "reader",
          id: state.reader,
          bytes: EMPTY2
        }
      ];
      return {
        state: {
          ...state,
          reader: event.id
        },
        effects: displaced
      };
    }
    case "end": {
      const effects = [];
      if (state.reader !== null) effects.push({
        to: "reader",
        id: state.reader,
        bytes: EMPTY2
      });
      for (const w of state.writers) effects.push({
        to: "writer",
        id: w.id,
        ok: false
      });
      return {
        state: {
          ...state,
          ended: true,
          reader: null,
          writers: []
        },
        effects
      };
    }
    case "endWith": {
      if (state.ended) return apply(state, {
        kind: "end"
      });
      if (state.reader !== null) {
        const handed = {
          ...state,
          reader: null
        };
        const closed = apply(handed, {
          kind: "end"
        });
        return {
          state: closed.state,
          effects: [
            {
              to: "reader",
              id: state.reader,
              bytes: event.bytes
            },
            ...closed.effects
          ]
        };
      }
      const held = {
        ...state,
        chunks: [
          ...state.chunks,
          event.bytes
        ],
        held: state.held + event.bytes.length
      };
      return apply(held, {
        kind: "end"
      });
    }
  }
}
var ByteQueue = class {
  #state;
  #readers = /* @__PURE__ */ new Map();
  #writers = /* @__PURE__ */ new Map();
  #next = 0;
  constructor(cap = 0) {
    this.#state = emptyQueue(cap);
  }
  #run(event) {
    const step = apply(this.#state, event);
    this.#state = step.state;
    for (const e of step.effects) {
      if (e.to === "reader") {
        const res = this.#readers.get(e.id);
        this.#readers.delete(e.id);
        res?.(e.bytes);
      } else {
        const res = this.#writers.get(e.id);
        this.#writers.delete(e.id);
        res?.(e.ok);
      }
    }
  }
  /**
   * Take these bytes, waiting for room if the queue is full, and answering false once it has ended.
   *
   * A real pipe blocks a writer whose reader is behind and fails one whose reader has gone; this does the
   * same. The child is parked in `Atomics.wait` on its own `write` call meanwhile, which is exactly the
   * shape a blocking write has on the other side of a bridge.
   */
  push(b) {
    const id = this.#next++;
    return new Promise((res) => {
      this.#writers.set(id, res);
      this.#run({
        kind: "push",
        id,
        bytes: b
      });
    });
  }
  /**
   * The next chunk, or empty once ended and drained.
   *
   * **Everything queued, up to `CHUNK`** — not literally the next thing pushed. A writer emitting a line
   * at a time and a reader across a bridge is one round trip per line otherwise: `seq 1 200000 | wc -l`
   * took forty-five seconds that way, almost all of it in parks and wakes. Coalescing is legal by the
   * protocol, which promises *at most* `CHUNK` bytes.
   */
  next() {
    const id = this.#next++;
    return new Promise((res) => {
      this.#readers.set(id, res);
      this.#run({
        kind: "next",
        id,
        limit: CHUNK
      });
    });
  }
  /**
   * Everything, to the end — for `readStdin`, which promises exactly that.
   *
   * A child's standard input arrives over time, so "all of it" means waiting for the end rather than
   * taking what is there. Serving `readStdin` with one chunk is the bug this exists to avoid:
   * `seq 1 5 | sort -r` printed `1`, because `sort` reads to the end before sorting and the end came
   * after one line.
   */
  async rest() {
    const parts = [];
    for (; ; ) {
      const c = await this.next();
      if (c.length === 0) return join(parts);
      parts.push(c);
    }
  }
  /** No more will arrive: a waiting reader gets the end, and a parked writer is refused. */
  end() {
    this.#run({
      kind: "end"
    });
  }
  /** One last thing, then the end — see `apply`'s `endWith` for why it is not push-then-end. */
  endWith(b) {
    this.#run({
      kind: "endWith",
      bytes: b
    });
  }
  /** What the queue is holding, for a caller narrating a stall. Reads nothing into the state. */
  describe() {
    const s = this.#state;
    return `${s.chunks.length} chunk(s) ${s.held}b${s.ended ? " ended" : ""}${s.reader === null ? "" : " reader-waiting"}${s.writers.length > 0 ? ` ${s.writers.length} writer(s) parked` : ""}`;
  }
};

// ../g/wac-new/packages/platform/host/children.ts
var QUEUE_CAP = 8 << 20;
var WORKER_MARKER = "//wac-worker 1";
var LOAD_GRACE_MS = 12e4;
function graceOf(ms) {
  return ms === void 0 || !Number.isFinite(ms) || ms <= 0 ? LOAD_GRACE_MS : ms;
}
var PARENT_FS_HANDLE = 1;
var FIRST_FREE_HANDLE = 2;
var NO_WASM_CHILD = "this host starts JavaScript worker bundles, and cannot start a wasm module here";
function looksLikeModule(bytes) {
  return bytes.length >= 4 && bytes[0] === 0 && bytes[1] === 97 && bytes[2] === 115 && bytes[3] === 109;
}
var CHILD_BYTES = "__wacChildBytes";
function wrapModule(wasm, moduleEntry) {
  if (!looksLikeModule(wasm)) {
    return new TextDecoder().decode(wasm);
  }
  if (moduleEntry === null) return NO_WASM_CHILD;
  let binary = "";
  for (let i = 0; i < wasm.length; i += 32768) {
    binary += String.fromCharCode(...wasm.subarray(i, i + 32768));
  }
  return `${WORKER_MARKER}
const b = atob(${JSON.stringify(btoa(binary))});
const bytes = new Uint8Array(b.length);
for (let i = 0; i < b.length; i++) bytes[i] = b.charCodeAt(i);
globalThis.${CHILD_BYTES} = bytes;
${moduleEntry}`;
}
function blobWorker(source) {
  const url = URL.createObjectURL(new Blob([
    source
  ], {
    type: "text/javascript"
  }));
  const worker = new Worker(url, {
    type: "module"
  });
  return {
    post: (m) => worker.postMessage(m),
    onMessage: (f) => {
      worker.onmessage = (e) => f(e.data);
    },
    onError: (f) => {
      worker.onerror = (e) => {
        e.preventDefault();
        f(e.message === "" ? "the worker failed to load" : e.message);
      };
      worker.onmessageerror = (e) => {
        e.preventDefault?.();
        f("the worker sent a message that could not be read");
      };
    },
    terminate: () => {
      worker.terminate();
      URL.revokeObjectURL(url);
    }
  };
}
var WriteThrough = class extends ByteQueue {
  #write;
  constructor(write) {
    super(0);
    this.#write = write;
  }
  push(b) {
    this.#write(b);
    return Promise.resolve(true);
  }
  /**
   * **The last line goes through too.** A child's trap reason is written with `endWith`, which this did not
   * override, so for a child that inherited the terminal — every program `wac run` starts — the reason went into
   * the zero-sized queue underneath, which nothing reads: a trap, a stack overflow included, was an exit status
   * and not a word (wac-sqlite).
   */
  endWith(b) {
    this.#write(b);
    this.end();
  }
};
function spawnChild(program, args, startWorld, makeBridge, makeWorker = blobWorker, graceMs, moduleEntry, sinks) {
  const out2 = sinks ? new WriteThrough(sinks.out) : new ByteQueue(QUEUE_CAP);
  const err = sinks ? new WriteThrough(sinks.err) : new ByteQueue(QUEUE_CAP);
  const input = new ByteQueue();
  const fsReq = new ByteQueue();
  const fsRep = new ByteQueue();
  const source = typeof program === "string" ? program : wrapModule(program, moduleEntry ?? null);
  if (!source.startsWith(WORKER_MARKER)) {
    const looksBuilt = source.includes("SharedArrayBuffer") || source.includes("wacBind");
    const why = source === NO_WASM_CHILD ? NO_WASM_CHILD : looksBuilt ? "built by an older wac than this one: rebuild it with --worker" : "not a wac program: no `wac.manifest` section and not a worker bundle";
    out2.end();
    err.end();
    input.end();
    return {
      out: out2,
      err,
      in: input,
      fsReq,
      fsRep,
      exit: Promise.resolve(-1),
      ended: Promise.resolve({
        how: 2,
        m: 0,
        text: "the child could not be started"
      }),
      loaded: Promise.resolve(why),
      kill: () => {
      }
    };
  }
  const bridge = makeBridge();
  const responder = startWorld(bridge.sab, args, out2, input, err, {
    req: fsReq,
    rep: fsRep
  }, source);
  const worker = makeWorker(source);
  let stopped = false;
  const shutdown = () => {
    if (stopped) return;
    stopped = true;
    responder.stop();
    worker.terminate();
    out2.end();
    err.end();
    fsReq.end();
    fsRep.end();
  };
  let settleLoaded;
  const loaded = new Promise((res) => {
    settleLoaded = res;
  });
  const grace = graceOf(graceMs);
  const assumeAlive = setTimeout(() => settleLoaded("did not report ready within " + grace + "ms: a worker bundle that does not speak the bridge protocol, or a machine too loaded to have evaluated it"), grace);
  const done = (why) => {
    clearTimeout(assumeAlive);
    settleLoaded(why);
  };
  let started = false;
  let settleExit;
  let settleEnded = () => {
  };
  const ended = new Promise((r) => {
    settleEnded = r;
  });
  const exit = new Promise((resolve) => {
    settleExit = resolve;
    worker.onMessage((data2) => {
      const r = data2;
      if ("ready" in r) {
        done("");
        started = true;
        return;
      }
      done("");
      started = true;
      if (!r.ok) {
        err.endWith(new TextEncoder().encode("wac: " + r.error.split("\n")[0] + "\n"));
      }
      shutdown();
      settleEnded(r.ok ? {
        how: 0,
        m: r.code,
        text: ""
      } : trapEnding(r.error));
      resolve(r.ok ? r.code : -1);
    });
    worker.onError((message) => {
      done(message);
      if (started) {
        err.endWith(new TextEncoder().encode("wac: " + message.split("\n")[0] + "\n"));
      }
      shutdown();
      settleEnded({
        how: 2,
        m: 0,
        text: message
      });
      resolve(-1);
    });
  });
  const kill = () => {
    done(started ? "" : "the child was killed before it reported ready");
    shutdown();
    settleEnded({
      how: 2,
      m: 0,
      text: "stopped by its parent"
    });
    settleExit(-1);
  };
  worker.post({
    sab: bridge.sab,
    child: true
  });
  return {
    out: out2,
    err,
    in: input,
    fsReq,
    fsRep,
    exit,
    ended,
    loaded,
    kill
  };
}
function trapEnding(error) {
  const line2 = error.split("\n")[0];
  if (line2.startsWith("trapped: ")) return {
    how: 1,
    m: 0,
    text: line2.slice("trapped: ".length)
  };
  const own = line2.indexOf("wac trap: ");
  if (own >= 0) return {
    how: 1,
    m: 0,
    text: line2.slice(own + "wac trap: ".length)
  };
  const w = line2.toLowerCase();
  const kind = w.includes("unreachable") ? 1 : w.includes("memory access out of bounds") || w.includes("array element access out of bounds") ? 2 : w.includes("table index is out of bounds") || w.includes("table access out of bounds") ? 3 : w.includes("divide by zero") || w.includes("remainder by zero") ? 4 : w.includes("divide result unrepresentable") || w.includes("integer overflow") ? 5 : w.includes("float unrepresentable") || w.includes("invalid conversion") ? 6 : w.includes("null") && (w.includes("dereferenc") || w.includes("function")) ? 7 : w.includes("illegal cast") || w.includes("signature mismatch") ? 8 : w.includes("call stack size exceeded") || w.includes("stack overflow") ? 9 : 10;
  return {
    how: 1,
    m: kind,
    text: kind === 1 ? "" : line2
  };
}
function childHandles(handle, errHandle, fsHandle, why) {
  const text = new TextEncoder().encode(why.split("\n")[0]);
  const out2 = new Uint8Array(12 + text.length);
  const dv = new DataView(out2.buffer);
  dv.setInt32(0, handle, true);
  dv.setInt32(4, errHandle, true);
  dv.setInt32(8, fsHandle, true);
  out2.set(text, 12);
  return out2;
}
function failedChild(why) {
  return childHandles(-1, -1, -1, why);
}
function noSpawnHere(why) {
  return childHandles(-2, -2, -2, why);
}
function want(p) {
  return new DataView(p.buffer, p.byteOffset, p.byteLength).getInt32(0, true);
}
function unpackSpawn(p) {
  const dv = new DataView(p.buffer, p.byteOffset, p.byteLength);
  const dec3 = new TextDecoder();
  const sourceLen = dv.getInt32(4, true);
  const source = p.slice(8, 8 + sourceLen);
  const argsAt = 8 + sourceLen;
  const after = unpackArgs(p, argsAt);
  const cwdLen = dv.getInt32(after.at, true);
  return {
    source,
    args: after.args,
    cwd: dec3.decode(p.subarray(after.at + 4, after.at + 4 + cwdLen)),
    // **Four bytes, not one**: `inherit` is `INHERIT_IN | INHERIT_OUT` rather than a bool.
    // `issues/system/0282c`.
    inheritIn: (dv.getInt32(after.at + 4 + cwdLen, true) & 1) !== 0,
    inheritOut: (dv.getInt32(after.at + 4 + cwdLen, true) & 2) !== 0,
    serveFs: p[after.at + 8 + cwdLen] === 1
  };
}
function unpackSpawnSelf(p) {
  const dv = new DataView(p.buffer, p.byteOffset, p.byteLength);
  const dec3 = new TextDecoder();
  const after = unpackArgs(p, 4);
  const cwdLen = dv.getInt32(after.at, true);
  return {
    args: after.args,
    cwd: dec3.decode(p.subarray(after.at + 4, after.at + 4 + cwdLen)),
    // `INHERIT_IN | INHERIT_OUT` in one byte, as `spawn` carries them in four.
    inheritIn: (p[after.at + 4 + cwdLen] & 1) !== 0,
    inheritOut: (p[after.at + 4 + cwdLen] & 2) !== 0,
    // **Two trailing flags now**, and the second is a promise rather than a grant: whether the
    // parent will answer this child's filesystem questions. See `spawnSelf` in platform.wac.
    serveFs: p[after.at + 5 + cwdLen] === 1
  };
}
function unpackArgs(p, at) {
  const dv = new DataView(p.buffer, p.byteOffset, p.byteLength);
  const count = dv.getInt32(at, true);
  let cursor = at + 4;
  const args = [];
  for (let i = 0; i < count; i++) {
    const len = dv.getInt32(cursor, true);
    args.push(p.slice(cursor + 4, cursor + 4 + len));
    cursor += 4 + len;
  }
  return {
    args,
    at: cursor
  };
}

// ../g/wac-new/packages/platform/host/browser.ts
var EMPTY3 = new Uint8Array(0);
function data(bytes) {
  const out2 = new Uint8Array(bytes.length + 1);
  out2[0] = 0;
  out2.set(bytes, 1);
  return out2;
}
var END = new Uint8Array([
  1
]);
function failed(why) {
  const message = new TextEncoder().encode(why);
  const out2 = new Uint8Array(message.length + 1);
  out2[0] = 2;
  out2.set(message, 1);
  return out2;
}
function withPeer(handle, peer, port = 0) {
  const text = new TextEncoder().encode(peer);
  const out2 = new Uint8Array(8 + text.length);
  const view = new DataView(out2.buffer);
  view.setInt32(0, handle, true);
  view.setInt32(4, port, true);
  out2.set(text, 8);
  return out2;
}
function browserWorld(opts = {}) {
  const asked = () => opts.askInterrupt !== void 0 && opts.askInterrupt();
  const args = opts.args ?? [];
  const warn = opts.warn ?? ((l) => console.warn(l));
  const write = opts.write ?? ((b) => console.log(new TextDecoder().decode(b)));
  const readIn = opts.readStdin;
  const readChunkIn = opts.readStdinChunk ?? opts.readStdin;
  const children = /* @__PURE__ */ new Map();
  const errStreams = /* @__PURE__ */ new Map();
  const fsChannels = /* @__PURE__ */ new Map();
  const reading = /* @__PURE__ */ new Map();
  const writing = /* @__PURE__ */ new Map();
  let nextHandle = FIRST_FREE_HANDLE;
  const startChild = async (source, childArgs, wanted, childCwd, inheritIn, serveFs) => {
    const give = {
      read: (wanted & GRANT_READ) !== 0 && opts.root !== void 0,
      write: (wanted & GRANT_WRITE) !== 0 && opts.root !== void 0 && opts.writable === true
    };
    const h = nextHandle++;
    const child = spawnChild(source, childArgs, (sab, cargs, out2, input, cerr, parentFs, childSelf) => {
      const enc3 = new TextEncoder();
      return serveHostCalls(bridgeOf(sab), browserWorld({
        args: cargs,
        // See `askInterrupt` above: a child learns that the user interrupted.
        askInterrupt: asked,
        // **Its parent's filesystem, on a handle of its own** — wac-mono 0116. A third authority
        // beside those two and separate from both: a child may learn that the user interrupted, may
        // not draw, and may ask its parent about files. In a page this is the one that matters
        // most, because a page has no filesystem of its own at all — the browser terminal's `/etc`,
        // `/proc` and `/bin` live in the shell's memory, and until this a spawned applet could not
        // see them.
        parentFs,
        // Its error output goes to the *other* stream, which `recv(errHandle)` reads. A program has two, and merging them made a shell count an error message in `cat x | wc -c`.
        warn: async (l) => {
          await cerr.push(enc3.encode(l + "\n"));
        },
        // A full queue has to *fail* the write, or a program written to stop when the other end
        // goes away never learns: `box yes` writes until a write fails. Throwing is how the host
        // says it failed.
        write: async (b) => {
          if (!await out2.push(b)) throw new Error("the child's output is not being read");
        },
        writeErr: async (b) => {
          await cerr.push(b);
        },
        closeOutput: (toErr) => {
          (toErr ? cerr : out2).end();
        },
        // `readStdin` means *all* of it, which for a child means waiting for its input to end: the
        // bytes arrive over time. Serving it with one chunk made `seq 1 5 | sort -r` print `1`, since
        // `sort` reads to the end before sorting. `readChunk` and `recv` still take one chunk.
        // **An inheriting child reads the real thing.** Leaving these out is what hands it over: a
        // world with no `readStdin` option falls back to the process's own input, so the child reads
        // the same stream its parent would have — streaming rather than buffered, and *shared*, which
        // is why `cat; cat` sees one line between them rather than one each. Issue 0042.
        ...inheritIn ? {} : {
          readStdin: () => input.rest(),
          readStdinChunk: () => input.next()
        },
        // **Write is delivered under read, and that is the Origin Private File System rather than a
        // bundle.** Reaching a file to write it means walking directory handles from the root, and
        // holding the root handle *is* the read capability here — there is no path-based open to
        // separate them, as there is under Deno and Node where `fs: { read: false, write: true }` is
        // a real thing. So a child asking for `GRANT_WRITE` alone gets no filesystem in a page, and
        // finds out the ordinary way: `writeFile` answers `FAULT_NOT_GRANTED`, which is true of it.
        //
        // Said here because the contract in `platform.wac` reads as four independent grants, and on
        // three of the four hosts it is. This is the one that cannot be, and a reader of that
        // sentence should not have to discover it.
        ...give.read ? {
          root: opts.root,
          writable: give.write
        } : {},
        // **Its own source, not this one's.** A program's "self" is what it was started as, and
        // passing `opts.selfSource` down was right only while every child was a bundle spawned from
        // the same one. A wasm child is not: under `wac app-run` the launcher's program is the `wac`
        // command and the application is a module, so the child's `spawnSelf` re-ran `wac` with the
        // caller's argv. `issues/system/0276c`.
        selfSource: childSelf,
        // Where its relative paths resolve from. A shell in a tab that has done `cd sub` starts its
        // children there, exactly as it would on a command line.
        cwd: childCwd === "" ? opts.cwd : childCwd
      }));
    }, newBridge);
    if (!serveFs) child.fsRep.end();
    const why = await child.loaded;
    if (why !== "") {
      child.kill();
      return failedChild(why);
    }
    const eh = nextHandle++;
    const fh = nextHandle++;
    children.set(h, child);
    errStreams.set(eh, child.err);
    fsChannels.set(fh, {
      req: child.fsReq,
      rep: child.fsRep
    });
    return childHandles(h, eh, fh, "");
  };
  const writeErr = opts.writeErr ?? ((b) => warn(new TextDecoder().decode(b)));
  const deny = (what) => {
    throw new Faulted(FAULT_NOT_GRANTED, `${what} not granted to this application`);
  };
  const root = () => opts.root ?? deny("filesystem read");
  const outClosed = [
    false,
    false
  ];
  const refuseClosed = (toErr) => {
    if (outClosed[toErr ? 1 : 0]) throw new Error("");
  };
  const canWrite = () => {
    if (opts.root === void 0 || opts.writable !== true) deny("filesystem write");
  };
  const describeAsPhrase = (fault, message) => {
    const phrase = phraseOf(fault);
    return phrase === "" ? message : phrase;
  };
  const readOrPhrase = async (work) => {
    try {
      return await work();
    } catch (e) {
      if (e instanceof Faulted) throw e;
      const message = e instanceof Error ? e.message : String(e);
      throw new Faulted(faultOf(e), describeAsPhrase(faultOf(e), message));
    }
  };
  const writeRefused = () => opts.root === void 0 || opts.writable !== true ? changeBytes(FAULT_NOT_GRANTED, "filesystem write not granted to this application") : null;
  const resolve = async (path, create) => {
    const parts = joinPath(opts.cwd ?? "", path).split("/").filter((p) => p !== "" && p !== ".");
    if (parts.length === 0) throw new Error("empty path");
    let dir = root();
    for (let i = 0; i < parts.length - 1; i++) {
      dir = await dir.getDirectoryHandle(parts[i], {
        create
      });
    }
    return {
      dir,
      name: parts[parts.length - 1]
    };
  };
  const fileOf = async (path) => {
    const { dir, name } = await resolve(path, false);
    return await (await dir.getFileHandle(name)).getFile();
  };
  const dirOf = async (path, create) => {
    const parts = joinPath(opts.cwd ?? "", path).split("/").filter((x) => x !== "" && x !== ".");
    let dir = root();
    for (const part of parts) dir = await dir.getDirectoryHandle(part, {
      create
    });
    return dir;
  };
  const statBytes = async (path) => {
    const out2 = new Uint8Array(STAT_BYTES);
    const dv = new DataView(out2.buffer);
    if (opts.root === void 0) {
      out2[STAT_FAULT] = FAULT_NOT_GRANTED;
      return out2;
    }
    try {
      const f = await fileOf(path);
      out2[0] = 1;
      out2[1] = 1;
      dv.setBigInt64(3, BigInt(f.size), true);
      dv.setBigInt64(11, BigInt(f.lastModified), true);
      return out2;
    } catch {
    }
    try {
      await dirOf(path, false);
      out2[0] = 1;
      out2[2] = 1;
    } catch {
    }
    return out2;
  };
  return {
    // `wac.http`'s requests, when the page offers it — numbered from its own range, so nothing here collides.
    ...opts.http ? httpHandlers(typeof opts.http === "function" ? opts.http : void 0) : {},
    [OP.NOW_MILLIS]: () => i64le(BigInt(Date.now())),
    [OP.MONOTONIC_NANOS]: () => i64le(BigInt(Math.round(performance.now() * 1e6))),
    // A timer, which is what makes a timeout expressible: waited on beside another ticket,
    // whichever lands first decides. Resolves to the monotonic nanoseconds at which it fired
    // rather than to nothing, so a caller can see the overshoot.
    // A page has no process directory. The root of the Origin Private File System is where its
    // relative paths land, so that is the true answer and not a placeholder.
    [OP.CWD]: () => str(opts.cwd !== void 0 && opts.cwd !== "" ? opts.cwd : "/"),
    [OP.SLEEP_MILLIS]: (p) => new Promise((ok) => setTimeout(() => ok(i64le(BigInt(Math.round(performance.now() * 1e6)))), readI32le(p))),
    [OP.RANDOM_BYTES]: (p) => randomBytes(readI32le(p)),
    /**
     * **The one host that can answer yes**, because in a page the keydown listener and the code
     * servicing this bridge are the same thread — so while the worker is parked here, the page has
     * already had its chance to see the keystroke.
     *
     * This is what makes design/system/0001 step 5's criterion reachable: a running applet is inside
     * `dispatch`, so the shell's own check points are not executing, and an applet holds a `Sys` and
     * never a `Page`.
     */
    [OP.ASK_INTERRUPT]: () => i32le(asked() ? 1 : 0),
    [OP.ARG_COUNT]: () => i32le(args.length),
    [OP.ARG]: (p) => {
      const i = readI32le(p);
      return i >= 0 && i < args.length ? argBytes(args[i]) : EMPTY_ARG;
    },
    // **Unset, always**: a page has no environment to withhold, so there is nothing to refuse. One byte of
    // presence says so, as it does everywhere else.
    [OP.ENV]: () => new Uint8Array([
      0
    ]),
    // A page has no standard input of its own; a child running inside it does.
    [OP.READ_STDIN]: async () => readIn === void 0 ? EMPTY3 : await readIn(),
    // A page has no pipe to break, so a failure here is a real one and keeps its words.
    [OP.WRITE_STDOUT]: async (p) => {
      refuseClosed(false);
      await write(p);
      return EMPTY3;
    },
    /**
     * Standard error as bytes. A page has one place for text, so this reaches the same sink `warn`
     * does — but without a newline, and without going through a string, so bytes that are not valid
     * UTF-8 survive as far as the page's own decoder rather than being mangled here.
     */
    [OP.WRITE_STDERR]: async (p) => {
      refuseClosed(true);
      await writeErr(p);
      return EMPTY3;
    },
    /**
     * A worker on the source it is handed, with a world of its own. Issue 0030.
     *
     * Nothing about a page forbade this: a worker can create a worker, each program needs its own
     * `SharedArrayBuffer` and a responder for it, and the page's own thread can host a second
     * responder as easily as the first. The parent is parked in `Atomics.wait` while its child runs,
     * and that is fine precisely because the child's calls are answered *here*, by the page, not by
     * the parent.
     *
     * The same `spawnChild` the Deno host uses, with a browser world instead of a Deno one — which
     * is the whole reason that function takes its world and its worker as arguments. What differs
     * between the two hosts is which world a child gets, and that is one expression.
     *
     * Its `log`, `warn`, `write` and `writeErr` go to the parent through the handle, and its reads
     * come from what the parent sends.
     */
    [OP.SPAWN]: (p) => {
      const { source, args: args2, cwd, inheritIn, serveFs } = unpackSpawn(p);
      return startChild(source, args2, want(p), cwd, inheritIn, serveFs);
    },
    /**
     * This same page's program again, with different arguments. See `spawnSelf` in platform.wac.
     *
     * **This is what gives a page programs to run at all.** `spawn` needs a bundle from a filesystem,
     * and a browser tab has no directory of programs — so a page could spawn and had nothing to
     * spawn. The launcher already holds this program's bundle, because it is what started it, and
     * `packages/box` decides which applet it is from its first argument. Issue 0030.
     */
    [OP.SPAWN_SELF]: (p) => {
      if (opts.selfSource === void 0) {
        return noSpawnHere("this page did not pass the program its own source");
      }
      const { args: args2, cwd, inheritIn, serveFs } = unpackSpawnSelf(p);
      return startChild(opts.selfSource, args2, want(p), cwd, inheritIn, serveFs);
    },
    [OP.CLOSE_FEED]: (p) => {
      children.get(readI32le(p))?.in.end();
      return EMPTY3;
    },
    [OP.CHILD_ENDED]: async (p) => {
      const c = children.get(readI32le(p));
      if (c === void 0) throw new Error("not a spawned worker");
      const e = await c.ended;
      const said = new TextEncoder().encode(e.text);
      const out2 = new Uint8Array(8 + said.length);
      new DataView(out2.buffer).setInt32(0, e.how, true);
      new DataView(out2.buffer).setInt32(4, e.m, true);
      out2.set(said, 8);
      return out2;
    },
    [OP.EXIT_CODE]: async (p) => {
      const c = children.get(readI32le(p));
      if (c === void 0) throw new Error("not a spawned worker");
      return i32le(await c.exit);
    },
    [OP.READ_FILE]: (p) => readOrPhrase(async () => new Uint8Array(await (await fileOf(unstr(p))).arrayBuffer())),
    [OP.WRITE_FILE]: (p) => {
      const no = writeRefused();
      if (no !== null) return no;
      const n = readI32le(p);
      return changed(async () => {
        const { dir, name } = await resolve(unstr(p.subarray(4, 4 + n)), true);
        const h = await dir.getFileHandle(name, {
          create: true
        });
        const w = await h.createWritable();
        await w.write(p.subarray(4 + n));
        await w.close();
      }, describeAsPhrase);
    },
    [OP.STAT]: (p) => statBytes(unstr(p)),
    // The Origin Private File System has no symbolic links, so this *is* `stat`, and `isSymlink`
    // stays false. That is true rather than a stand-in — and it is why `tar` can refuse links in a
    // page as well, without knowing which host it is on.
    //
    // `isExecutable` and the mode stay zero for the same kind of reason rather than being written:
    // OPFS has no mode bits, so nothing in a page is executable and saying so is the answer rather
    // than a gap. Writing it is the half that has to refuse — see `SET_EXECUTABLE` below.
    [OP.LINK_STAT]: (p) => statBytes(unstr(p)),
    [OP.READ_DIR]: async (p) => {
      const h = await dirOf(unstr(p), false);
      const names = [];
      for await (const key of h.keys()) {
        names.push(key);
      }
      return str(names.sort().join("\0"));
    },
    /**
     * `exec` — **always refused here, and there is no option that turns it on.**
     *
     * A page has no host to run a program on. This is the capability the browser must be able to
     * say no to while still saying yes to `spawn`, which starts a confined wasm module in a worker
     * — the reason the two are separate capabilities rather than one. `issues/system/0165`.
     */
    [OP.EXEC]: () => execBytes(0, EMPTY3, EMPTY3, "a page cannot run a host program"),
    [OP.MKDIR]: (p) => {
      const no = writeRefused();
      if (no !== null) return no;
      const path = unstr(p.subarray(1));
      if (p[0] === 1) {
        return changed(async () => {
          const { dir, name } = await resolve(path, true);
          await dir.getDirectoryHandle(name, {
            create: true
          });
        }, describeAsPhrase);
      }
      return changed(async () => {
        const { dir, name } = await resolve(path, false);
        let exists = true;
        try {
          await dir.getDirectoryHandle(name);
        } catch {
          exists = false;
        }
        if (exists) throw new Faulted(FAULT_EXISTS, "already exists");
        await dir.getDirectoryHandle(name, {
          create: true
        });
      }, describeAsPhrase);
    },
    [OP.REMOVE]: (p) => {
      const no = writeRefused();
      if (no !== null) return no;
      return changed(async () => {
        const { dir, name } = await resolve(unstr(p.subarray(1)), false);
        await dir.removeEntry(name, {
          recursive: p[0] === 1
        });
      }, describeAsPhrase);
    },
    [OP.RENAME]: (p) => {
      const no = writeRefused();
      if (no !== null) return no;
      const n = readI32le(p);
      const from = unstr(p.subarray(4, 4 + n));
      const to = unstr(p.subarray(4 + n));
      return changed(async () => {
        const bytes = new Uint8Array(await (await fileOf(from)).arrayBuffer());
        const dst = await resolve(to, true);
        const h = await dst.dir.getFileHandle(dst.name, {
          create: true
        });
        const w = await h.createWritable();
        await w.write(bytes);
        await w.close();
        const src = await resolve(from, false);
        await src.dir.removeEntry(src.name);
      }, describeAsPhrase);
    },
    // **The capability is present and the backing refuses**, which is a different statement from the
    // capability being absent and the reason it is `FAULT_UNSUPPORTED` rather than `FAULT_NOT_GRANTED`.
    // The Origin Private File System has no mode bits: there is nothing here to set, so a page cannot
    // make a file executable and nothing in a page is executable to begin with — which is why
    // `Stat.isExecutable` is answered false rather than left unimplemented. 0117 added the word for
    // exactly this, and a caller that only checked "did it fail" would report the file's fault instead.
    [OP.SET_EXECUTABLE]: () => {
      const no = writeRefused();
      if (no !== null) return no;
      return changeBytes(FAULT_UNSUPPORTED, "a page's filesystem has no mode bits");
    },
    // The same answer for the whole mode, and for the same reason. `Files.setExecutable`'s note gives
    // "a browser's OPFS has no mode bits at all" as one of three reasons it was one bit rather than a
    // mode — the point being that `FAULT_UNSUPPORTED` says *the backing refuses* rather than *nobody
    // implemented this*. That distinction is what lets the wider call exist here at all.
    [OP.CHMOD]: () => {
      const no = writeRefused();
      if (no !== null) return no;
      return changeBytes(FAULT_UNSUPPORTED, "a page's filesystem has no mode bits");
    },
    // A spawned child's standard input is a queue its parent fills; a page has none of its own.
    [OP.READ_CHUNK]: async () => {
      if (readChunkIn === void 0) return END;
      const piped = await readChunkIn();
      return piped.length === 0 ? END : data(piped);
    },
    /** A file as a stream of its own — see the note in `deno.ts`. */
    [OP.OPEN_FILE]: async (p) => {
      const how = readI32le(p);
      const path = unstr(p.subarray(4));
      if (how === 3 || how === 4) throw new Faulted(FAULT_UNSUPPORTED, `${path}: a page's files open as streams only`);
      if (how === 0) {
        const blob = await readOrPhrase(() => fileOf(path));
        const h2 = nextHandle++;
        reading.set(h2, {
          blob,
          at: 0
        });
        return withPeer(h2, "");
      }
      canWrite();
      const { dir, name } = await resolve(path, true);
      const file = await (await dir.getFileHandle(name, {
        create: true
      })).createWritable({
        keepExistingData: how === 2
      });
      if (how === 2) await file.seek((await (await dir.getFileHandle(name)).getFile()).size);
      const h = nextHandle++;
      writing.set(h, file);
      return withPeer(h, "");
    },
    /**
     * The end of this program's output or its diagnostic output — see the note in `deno.ts`. A page's own
     * console has no end to give, so there it only refuses later writes.
     */
    [OP.CLOSE_OUTPUT]: (p) => {
      const toErr = readI32le(p) !== 0;
      if (outClosed[toErr ? 1 : 0]) return EMPTY3;
      outClosed[toErr ? 1 : 0] = true;
      opts.closeOutput?.(toErr);
      return EMPTY3;
    },
    /**
     * The end of a file opened with `OPEN_FILE`. Awaited, because closing a `WritableFile` is what makes its
     * bytes the file's: a program that closes and then reads has to find them there.
     */
    [OP.CLOSE_FILE]: async (p) => {
      const h = readI32le(p);
      const w = writing.get(h);
      const known = w !== void 0 || reading.has(h);
      writing.delete(h);
      reading.delete(h);
      if (!known) throw new Error("not an open file");
      if (w !== void 0) await w.close();
      return EMPTY3;
    },
    // No TCP in a page, and no honest approximation of one.
    [OP.CONNECT]: () => deny("network access"),
    [OP.LISTEN]: () => deny("network access"),
    [OP.ACCEPT]: () => deny("network access"),
    // **No UDP either, and this needs no new argument.** WebTransport is QUIC offered as a service
    // over HTTP/3, with the datagrams framed by somebody else's stack and the connection made on
    // your behalf — which is the opposite of what a datagram capability is for. Handing it over as
    // `sendTo` would give an application something that works for one shape of traffic and silently
    // fails for the rest, which is the argument three lines up. design/system 0007.
    [OP.BIND_DATAGRAM]: () => deny("network access"),
    [OP.RECEIVE_FROM]: () => deny("network access"),
    [OP.SEND_TO]: () => deny("network access"),
    // Handle 0 is standard input everywhere else; a page has none, so it ends immediately
    // rather than refusing. Any other handle is a socket, which a page cannot have.
    // A page has no standard input and no sockets, so handle 0 is immediately at its end and
    // anything else is refused — as a `Read`, so a caller cannot read the refusal as "finished".
    [OP.RECV]: async (p) => {
      const h = readI32le(p);
      if (h === 0) {
        if (readChunkIn === void 0) return END;
        const piped = await readChunkIn();
        return piped.length === 0 ? END : data(piped);
      }
      const kid = children.get(h);
      if (kid !== void 0) {
        const fromChild = await kid.out.next();
        return fromChild.length === 0 ? END : data(fromChild);
      }
      const complaint = errStreams.get(h);
      if (complaint !== void 0) {
        const said = await complaint.next();
        return said.length === 0 ? END : data(said);
      }
      if (h === PARENT_FS_HANDLE && opts.parentFs !== void 0) {
        const answer = await opts.parentFs.rep.next();
        return answer.length === 0 ? END : data(answer);
      }
      const asking = fsChannels.get(h);
      if (asking !== void 0) {
        const request = await asking.req.next();
        return request.length === 0 ? END : data(request);
      }
      const file = reading.get(h);
      if (file !== void 0) {
        try {
          const end = Math.min(file.at + CHUNK, file.blob.size);
          if (end <= file.at) return END;
          const slice = file.blob.slice(file.at, end);
          file.at = end;
          return data(new Uint8Array(await slice.arrayBuffer()));
        } catch (e) {
          return failed(e instanceof Error ? e.message : String(e));
        }
      }
      return failed("network access is not granted");
    },
    // A child's standard input. Sockets are a page's other missing capability, and asking for one
    // is still a denial — but a handle that names a child is not a socket, and the check has to come
    // first or a page could spawn a program it can never feed.
    [OP.SEND]: async (p) => {
      const kid = children.get(readI32le(p));
      if (kid !== void 0) {
        if (!await kid.in.push(p.slice(4))) throw new Error("the child's input has ended");
        return EMPTY3;
      }
      if (readI32le(p) === PARENT_FS_HANDLE && opts.parentFs !== void 0) {
        await opts.parentFs.req.push(p.slice(4));
        return EMPTY3;
      }
      const answering = fsChannels.get(readI32le(p));
      if (answering !== void 0) {
        await answering.rep.push(p.slice(4));
        return EMPTY3;
      }
      const file = writing.get(readI32le(p));
      if (file !== void 0) {
        await file.write(p.slice(4));
        return EMPTY3;
      }
      return deny("network access");
    },
    /**
     * No raw sockets in a page, so there is no outbound direction to end — `issues/system/0215`.
     *
     * Refused by the same `deny` as `connect` and `listen` above rather than passed over quietly: a
     * program that half-closes a socket it could never have opened should hear about the socket.
     */
    [OP.CLOSE_SEND]: () => deny("network access"),
    [OP.CLOSE_SOCKET]: (p) => {
      const h = readI32le(p);
      const kid = children.get(h);
      if (kid !== void 0) {
        try {
          kid.in.end();
          kid.kill();
        } catch {
        }
      }
      const channel = fsChannels.get(h);
      if (channel !== void 0) {
        channel.req.end();
        channel.rep.end();
        fsChannels.delete(h);
      }
      return EMPTY3;
    }
  };
}

// ../g/wac-new/packages/platform/host/provider.ts
var EMPTY4 = new Uint8Array(0);
var NEEDS = {
  [OP.READ_FILE]: GRANT_READ,
  [OP.STAT]: GRANT_READ,
  [OP.LINK_STAT]: GRANT_READ,
  [OP.READ_DIR]: GRANT_READ,
  [OP.WRITE_FILE]: GRANT_WRITE,
  [OP.MKDIR]: GRANT_WRITE,
  [OP.REMOVE]: GRANT_WRITE,
  [OP.RENAME]: GRANT_WRITE,
  [OP.SET_EXECUTABLE]: GRANT_WRITE,
  [OP.CHMOD]: GRANT_WRITE,
  [OP.CONNECT]: GRANT_NET,
  [OP.LISTEN]: GRANT_NET,
  [OP.BIND_DATAGRAM]: GRANT_NET,
  [OP.ENV]: GRANT_ENV,
  [OP.EXEC]: GRANT_RUN
};
var AT_ONCE = /* @__PURE__ */ new Set([
  OP.NOW_MILLIS,
  OP.MONOTONIC_NANOS,
  OP.RANDOM_BYTES,
  OP.ARG_COUNT,
  OP.ARG,
  OP.ENV,
  OP.CWD,
  OP.WRITE_STDOUT,
  OP.WRITE_STDERR,
  OP.CLOSE_OUTPUT,
  OP.CLOSE_SOCKET,
  OP.CLOSE_SEND,
  OP.CLOSE_FEED
]);

// ../g/wac-new/packages/platform/host/entryBrowser.ts
async function runInPage(opts) {
  const isolated = globalThis.crossOriginIsolated;
  if (isolated !== true) return await runInPageAsync(opts);
  const bridge = newBridge();
  const responder = serveHostCalls(bridge, browserWorld({
    ...opts,
    selfSource: opts.workerSource
  }));
  if (opts.workerSource === void 0 && opts.workerUrl === void 0) {
    throw new Error("runInPage: neither a worker's source nor where it is");
  }
  const url = opts.workerSource !== void 0 ? URL.createObjectURL(new Blob([
    opts.workerSource
  ], {
    type: "text/javascript"
  })) : String(opts.workerUrl);
  const worker = new Worker(url, {
    type: "module"
  });
  try {
    const code = await new Promise((resolve, reject) => {
      worker.addEventListener("message", (ev) => {
        const r = ev.data;
        if ("ready" in r) return;
        if (r.ok) resolve(r.code);
        else reject(new Error(r.error));
      });
      worker.addEventListener("error", (e) => {
        e.preventDefault();
        reject(new Error(e.message));
      });
      worker.postMessage({
        sab: bridge.sab,
        provides: opts.http ? [
          HOST_HTTP
        ] : []
      });
    });
    return code;
  } finally {
    responder.stop();
    worker.terminate();
    if (opts.workerSource !== void 0) URL.revokeObjectURL(url);
  }
}
async function runInPageAsync(opts) {
  if (opts.workerSource === void 0 && opts.workerUrl === void 0) {
    throw new Error("runInPage: neither a worker's source nor where it is");
  }
  const opaque = globalThis.origin === "null";
  let source = opts.workerSource;
  let base = void 0;
  if (source === void 0 && opaque) {
    base = String(new URL(String(opts.workerUrl), location.href));
    const res = await fetch(base);
    if (!res.ok) throw new Error(`${base}: ${res.status}`);
    source = await res.text();
  }
  const url = source === void 0 ? String(opts.workerUrl) : opaque ? "data:text/javascript;base64," + base64(new TextEncoder().encode(source)) : URL.createObjectURL(new Blob([
    source
  ], {
    type: "text/javascript"
  }));
  const worker = new Worker(url, {
    type: "module"
  });
  try {
    return await new Promise((resolve, reject) => {
      worker.addEventListener("message", (ev) => {
        const m = ev.data;
        if ("ready" in m) return;
        if ("said" in m) {
          if (m.said === "warn") void opts.warn?.(m.line);
          else if (m.said === "close") opts.closeOutput?.(m.toErr);
          else if (m.said === "write") void opts.write?.(m.bytes);
          else void opts.writeErr?.(m.bytes);
          return;
        }
        if (m.ok) resolve(m.code);
        else reject(new Error(m.error));
      });
      worker.addEventListener("error", (e) => {
        e.preventDefault();
        reject(new Error(e.message));
      });
      const start = {
        async: true,
        args: opts.args ?? [],
        root: opts.root,
        writable: opts.writable,
        http: opts.http === true,
        cwd: opts.cwd,
        has: {
          write: !!opts.write,
          writeErr: !!opts.writeErr,
          warn: !!opts.warn,
          closeOutput: !!opts.closeOutput
        },
        base
      };
      worker.postMessage(start);
    });
  } finally {
    worker.terminate();
    if (url.startsWith("blob:")) URL.revokeObjectURL(url);
  }
}
function base64(bytes) {
  let bin = "";
  for (let i = 0; i < bytes.length; i += 32768) bin += String.fromCharCode(...bytes.subarray(i, i + 32768));
  return btoa(bin);
}
async function argsFromPage(search, base) {
  try {
    const res = await fetch(new URL("args.json", base));
    if (res.ok) {
      const got = await res.json();
      if (Array.isArray(got) && got.every((a) => typeof a === "string")) return got;
      throw new Error("args.json must be an array of strings");
    }
  } catch (e) {
    if (e instanceof Error && e.message.startsWith("args.json")) throw e;
  }
  return argsFromLocation(search);
}
function argsFromLocation(search) {
  return new URLSearchParams(search).getAll("a");
}

// ../../../../../wac-app/launcher.ts
var out = document.getElementById("out");
var line = (t, cls) => {
  const s = document.createElement("span");
  if (cls) s.className = cls;
  s.textContent = t + "\n";
  out.appendChild(s);
};
var raw = (b) => {
  const s = document.createElement("span");
  s.textContent = new TextDecoder().decode(b);
  out.appendChild(s);
};
try {
  const root = await navigator.storage.getDirectory();
  const code = await runInPage({
    workerUrl: new URL("worker.js", import.meta.url),
    args: await argsFromPage(location.search, import.meta.url),
    warn: (l) => line(l, "warn"),
    write: raw,
    root,
    writable: true,
    http: true
  });
  line("[exit " + code + "]", "meta");
} catch (e) {
  line(String(e && e.message ? e.message : e), "warn");
}
